-- Presentation defaults only. Economy remains in config.lua, owned by core.
return {maxWidth=1920,rowsPerPage=30,language='uk',terminalPollMs=500}
