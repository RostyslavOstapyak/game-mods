# Stop Searching - Always-On Objective Highlight

Spend your heist finding the loot, not hunting the same office for a tiny keycard.

ObjectiveHighlight automatically outlines supported mission clues, access items and script-selected computers, including through walls. It stays on: no hotkeys, no F7 and no need to aim at an item first.

## Features

- Highlights supported clue boards and inventory pickups such as access badges/keycards.
- Selects computers from explicit mission references or a correct-target flag, rather than highlighting every computer indiscriminately.
- Uses shared game components and mission references, without hardcoded mission names, employee names or coordinates.
- Does not interact with objects or complete objectives for you.
- Version 0.5.1 caches validated objects and only changes render state when necessary. The tester confirmed that the earlier once-per-second freezes disappeared while highlights remained visible.

## Coverage and limits

The board, badge and correct computer were verified in The Hidden Vault. A mission completion test succeeded during development; the final 0.5.1 performance fix was then checked in a running mission. Other missions still need reports: shared detection is not a guarantee that every mission-specific objective is covered.

Some items may appear before their objective becomes active. A board can stay highlighted after reading while its clue component remains enabled. Objects using different mission systems may not be detected. Allow a short delay after loading or spawning.

## Enable and troubleshoot

Enable line: ObjectiveHighlight : 1

Requires UE4SS APIs including LoopInGameThreadWithDelay, NotifyOnNewObject and RegisterLoadMapPostHook. If nothing appears, check ue4ss/UE4SS.log for [ObjectiveHighlight]. STOPPED means the controller stopped after an error. For a report, include the game build, UE4SS version, mission name and which object is missing; remove personal information from any log excerpt.

Version: 0.5.1. No game executable edits. Avoid combining with other mods that force outlines on the same objects.

## Requirements

Windows x64 and Crime Boss: Rockay City, Steam build 25106786.
Install UE4SS separately from https://github.com/UE4SS-RE/RE-UE4SS/releases .
The tested loader is UE4SS v3.0.1-971-g9ec5ece7 (experimental development build). Compatibility with other UE4SS versions is not confirmed; do not assume stable v3.0.1 exposes the same APIs. UE4SS is not bundled.

Use the UE4SS layout with UE4SS.dll in CrimeBoss/Binaries/Win64/ue4ss and the proxy DLL beside the game executable. Neither mod requires the other.

## Installation

Close the game. Back up ue4ss/Mods/mods.txt, then copy this archive's named mod folder into CrimeBoss/Binaries/Win64/ue4ss/Mods. Add the enable line shown below to mods.txt, replacing an existing entry for that mod rather than duplicating it. Start the game normally.

Alternatively, run the included Install.ps1 with -GameRoot pointing to your CrimeBossRockayCity installation folder. The optional installer checks the tested game executable and backs up the existing mod/configuration. It does not install UE4SS. Manual installation does not verify the executable hash.

Close and restart the game after installing, disabling or updating. Set the mod entry to 0 to disable it, or use Disable.ps1 with -GameRoot. Do not replace your entire mods.txt with another user's file.

## Compatibility

Verified configuration: Steam build 25106786, Windows x64, UE4SS v3.0.1-971-g9ec5ece7. Other game builds/storefronts and multiplayer are untested. No online compatibility or online benefits are promised.

The cover is AI-generated promotional artwork, not an in-game screenshot.