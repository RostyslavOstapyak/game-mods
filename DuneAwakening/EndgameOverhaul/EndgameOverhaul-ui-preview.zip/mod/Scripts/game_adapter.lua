-- Endgame Overhaul native boundary. Source only; never run during authoring.
-- Independent implementation using the verified wallet/exact-delete interfaces.
local M={}
local MAX=9007199254740990
local function integer(n,lo,hi)return type(n)=='number'and n==n and n%1==0 and n>=(lo or 0)and n<=(hi or MAX)end
local function valid(o)return o and o:IsValid()end
local function native(path)local o=StaticFindObject(path);assert(valid(o),'Native interface unavailable: '..path);return o end
local function token(s)return type(s)=='string'and #s>0 and #s<=192 and s:match('^[%w_:%-]+$')end
local function hex(s)return(tostring(s):gsub('.',function(c)return string.format('%02x',c:byte())end))end
local function encode_items(items)
 local a={};for id,n in pairs(items or{})do assert(token(id)and integer(n,1,2147483647),'Invalid item receipt');a[#a+1]=id..'='..n end
 table.sort(a);return #a>0 and table.concat(a,',')or'-'
end
local function decode_items(s)
 local out={};if s=='-'then return out end
 for id,n in s:gmatch('([%w_:%-]+)=(%d+)')do assert(not out[id],'Duplicate receipt item');out[id]=assert(tonumber(n))end
 assert(encode_items(out)==s,'Malformed item receipt');return out
end
local function signature(path,fields)
 local o=native(path);local actual={};o:ForEachProperty(function(p)actual[#actual+1]=p:GetFullName()end)
 assert(#actual==#fields,'Native signature changed: '..path)
 for i,v in ipairs(fields)do assert(actual[i]==v[1]..' '..path..':'..v[2],'Native field changed: '..v[2])end
 return o
end
function M.new(app,root)
 assert(type(root)=='string'and #root>0,'Mod root required')
 local self={busy=false,records={},blocked=nil,identityProvider=nil,manualProfile=nil}
 local journal=root..'/native-transfers.tsv'
 local bytes=0
 -- A truncated or unreadable checkpoint is never treated as a new account.
 local loaded,loadError=pcall(function()
  local f,why,code=io.open(journal,'rb')
  if not f then assert(code==2,why or'Cannot read native journal');return end
  local s=f:read(2097153);f:close();assert(#s<=2097152 and(s==''or s:sub(-1)=='\n'),'Native journal truncated/too large');bytes=#s
  for line in s:gmatch('([^\n]+)\n')do
   local v={};for x in(line..'\t'):gmatch('(.-)\t')do v[#v+1]=x end
   assert(#v==9 and v[1]=='EG1'and token(v[2])and token(v[3]),'Invalid native journal record')
   assert(v[5]=='intent'or v[5]=='confirmed'or v[5]=='review','Invalid native journal state')
   local before,after,amount=tonumber(v[6]),tonumber(v[7]),tonumber(v[8])
   assert(integer(before)and integer(after)and integer(amount),'Invalid journal amounts')
   local old=self.records[v[2]]
   if old then assert(old.context==v[3]and old.kind==v[4]and old.amount==amount,'Journal identity conflict')end
   self.records[v[2]]={id=v[2],context=v[3],kind=v[4],state=v[5],before=before,after=after,amount=amount,items=decode_items(v[9])}
  end
  for _,r in pairs(self.records)do if r.state~='confirmed'then self.blocked='Unresolved native operation '..r.id end end
 end)
 if not loaded then self.blocked='Native journal requires review: '..tostring(loadError)end
 local function append(r,state)
  assert(bytes<2000000,'Native journal needs manual archival after reconciliation')
  local line=table.concat({'EG1',r.id,r.context,r.kind,state,string.format('%.0f',r.before),string.format('%.0f',r.after),string.format('%.0f',r.amount),encode_items(r.items)},'\t')..'\n'
  local f=assert(io.open(journal,'ab'),'Cannot open native journal')
  local ok,why=f:write(line);if ok then ok,why=f:flush()end
  local closed=f:close();assert(ok and closed,why or'Cannot persist native journal')
  bytes=bytes+#line;r.state=state;self.records[r.id]=r
 end
 local function session()
  app._controller=nil
  local s=app:session();assert(s and s.ok and valid(s.controller)and valid(s.pawn),'Load a singleplayer character')
  assert(s.controller.Role==3 and s.pawn.Role==3,'Local authority required')
  assert(native('/Script/DuneSandbox.Default__GUIBlueprintLibrary'):IsSoloPlay(s.pawn),'Singleplayer required')
  return s
 end
 local function session_token(s)
  local world=s.controller:GetWorld();assert(valid(world),'World unavailable')
  return table.concat({tostring(s.controller:GetAddress()),tostring(s.pawn:GetAddress()),
   tostring(world:GetAddress()),world:GetFullName()},'|')
 end
 -- Host may bind ONLY a verified durable character + save/world identity provider.
 -- Actor addresses, player names and map names are not persistent identity substitutes.
 function self:bind_identity(provider)
  assert(not self.busy and type(provider)=='function','Identity provider unavailable')
  self.identityProvider=provider;self.manualProfile=nil
 end
 -- Explicitly selected persistent MOD profile, never claimed as native identity.
 -- Only the association with the current actor/world session lives in memory.
 function self:profile_context()
  local ok,result=pcall(function()
   local s=session();local stamp=session_token(s)
   if self.manualProfile and self.manualProfile.session~=stamp then self.manualProfile=nil end
   local name='';pcall(function()name=s.controller.PlayerState:GetPlayerName():ToString()end)
   return {session=stamp,characterLabel=name,worldLabel=s.controller:GetWorld():GetFullName(),
    profileId=self.manualProfile and self.manualProfile.id or nil,
    manual=self.manualProfile~=nil,providerBound=self.identityProvider~=nil,
    requiresSelection=self.identityProvider==nil and self.manualProfile==nil}
  end)
  if ok then return result end
  self.manualProfile=nil;return nil,tostring(result)
 end
 function self:select_profile(profileId,confirmation)
  local ok,key=pcall(function()
   assert(not self.busy,'Wait for the pending native operation')
   assert(self.identityProvider==nil,'A verified automatic identity provider is already bound')
   assert(type(profileId)=='string'and #profileId>=1 and #profileId<=48
    and profileId:match('^[a-z0-9][a-z0-9_%-]*$'),'Use a unique lower-case profile id, 1 to 48 characters')
   assert(type(confirmation)=='table'and confirmation.confirmed==true
    and type(confirmation.session)=='string','Explicit profile confirmation with current session is required')
   local s=session();local stamp=session_token(s)
   assert(confirmation.session==stamp,'Session changed; select and confirm the profile again')
   local key='manual1:'..hex(profileId)
   self.manualProfile={id=profileId,key=key,session=stamp}
   return key
  end)
  if ok then return key end;return nil,tostring(key)
 end
 function self:clear_profile()
  -- Also called by the host on loading/travel/respawn, including while pending.
  -- An in-flight action then fails its context guard and enters review.
  self.manualProfile=nil
 end
 function self:context_key()
  local ok,key=pcall(function()
   local s=session()
   if not self.identityProvider then
    local chosen=self.manualProfile
    if chosen and chosen.session==session_token(s)then return chosen.key end
    self.manualProfile=nil
    error('Select and explicitly confirm a character/save profile for this session')
   end
   local v=self.identityProvider(s)
   assert(type(v)=='table'and type(v.character)=='string'and type(v.world)=='string'
    and #v.character>0 and #v.character<=40 and #v.world>0 and #v.world<=40,'Persistent identity unavailable')
   return 'eg1:'..hex(v.world)..':'..hex(v.character)
  end)
  if ok then return key end;self.manualProfile=nil;return nil,tostring(key)
 end
 local function capture()
  local s=session();local k,why=self:context_key();assert(k,why)
  local w=s.controller:GetWorld();assert(valid(w),'World unavailable')
  return {key=k,controller=s.controller:GetAddress(),pawn=s.pawn:GetAddress(),world=w:GetAddress()},s
 end
 local function current(origin)
  local now,s=capture();assert(now.key==origin.key and now.controller==origin.controller and now.pawn==origin.pawn and now.world==origin.world,'Character/world changed during transfer');return s
 end
 local function balance(pc)local n=pc.m_VirtualWalletBalances[1];assert(integer(n),'Bank balance unavailable or outside exact range');return n end
 function self:get_balance()
  local ok,n=pcall(function()return balance(session().controller)end);if ok then return n end;return nil,tostring(n)
 end
 local function async(fn,done)
  assert(type(done)=='function','Completion callback required')
  if self.busy then
   local ok,t=pcall(function()return app:defer(1,function()done(false,{error='Native operation already pending',pending=true})end)end)
   return ok and t and {pending=true}or nil
  end
  self.busy=true
  local finished=false
  local function finish(ok,r)
   if finished then return end;finished=true;self.busy=false
   local called,why=pcall(done,ok,r);if not called then self.blocked='Consumer callback failed; reconcile native journal: '..tostring(why)end
  end
  local ok,t=pcall(function()return app:defer(1,function()
   local ran,err=pcall(fn,finish)
   if not ran then finish(false,{error=tostring(err),review=self.blocked~=nil})end
  end)end)
  if not ok or not t then finish(false,{error='Async scheduler unavailable',review=false});return nil end
  return {pending=true}
 end
 local function start(id,kind,amount,key)
  assert(token(id),'Invalid operation id');assert(not self.blocked,self.blocked)
  local previous=self.records[id]
  if previous then
   assert(previous.context==key and previous.kind==kind and previous.amount==amount,'Operation id reused with different arguments')
   assert(previous.state=='confirmed','Unresolved operation; no replay allowed')
   return previous
  end
  self.busy=true
 end
 local function review(r,finish,why)
  self.blocked='Native operation '..r.id..' needs review: '..tostring(why)
  pcall(append,r,'review')
  finish(false,{id=r.id,error=tostring(why),review=true,before=r.before,expected=r.after,items=r.items})
 end
 local function receipt(r)return{id=r.id,context=r.context,before=r.before,after=r.after,amount=r.amount,items=r.items,confirmed=true}end
 function self:transfer(kind,amount,id,done)
  return async(function(finish)
   assert(kind=='deposit'or kind=='withdraw','Unknown bank direction');assert(integer(amount,1,1000000000),'Transfer must be a whole amount, maximum 1 billion')
   local origin,s=capture();local old=start(id,kind,amount,origin.key)
   if old then finish(true,receipt(old));return end
   local before=balance(s.controller);local after=before+(kind=='deposit'and-amount or amount)
   assert(integer(after),'Insufficient bank funds or exact range exceeded')
   signature('/Script/DuneSandbox.DuneCheatManager:AddSolarisToAccount',{{'Int64Property','Quantity'}})
   local manager=s.controller.CheatManager
   if not valid(manager)then manager=StaticConstructObject(native('/Script/DuneSandbox.DuneCheatManager'),s.controller,0,64)end
   assert(valid(manager),'Bank manager unavailable')
   local r={id=id,context=origin.key,kind=kind,amount=amount,before=before,after=after,items={}}
   local wrote,err=pcall(append,r,'intent')
   if not wrote then self.blocked='Journal write failed before bank action: '..tostring(err);finish(false,{error=tostring(err),review=true});return end
   local sent,why=pcall(function()
    local pc=current(origin).controller;assert(pc:GetAddress()==s.controller:GetAddress()and balance(pc)==before,'Bank changed before transfer')
    manager:AddSolarisToAccount(kind=='deposit'and-amount or amount)
   end)
   if not sent then review(r,finish,why);return end
   local tries=0
   local function poll()
    local ok,value=pcall(function()return balance(current(origin).controller)end)
    if not ok then review(r,finish,value);return end
    if value==after then
     local saved,why=pcall(append,r,'confirmed');if not saved then review(r,finish,why);return end
     finish(true,receipt(r));return
    end
    tries=tries+1
    if value~=before or tries>=12 then review(r,finish,'Bank delta not confirmed; no automatic retry');return end
    local scheduled,t=pcall(function()return app:defer(500,poll)end);if not scheduled or not t then review(r,finish,'Bank receipt scheduler unavailable')end
   end
   local scheduled,t=pcall(function()return app:defer(700,poll)end);if not scheduled or not t then review(r,finish,'Bank receipt scheduler unavailable')end
  end,done)
 end
 -- Direct optional public native read functions. No foreign Lua-state bridge injection.
 local function inventory(s)
  local c=s.pawn.m_BackpackInventoryComponent;assert(valid(c),'Backpack component unavailable')
  local inv=c:GetInventory();assert(valid(inv)and inv:IsInitialContentReceived(),'Backpack is loading');return inv,c
 end
 local function parse(payload,address)
  assert(type(payload)=='string'and #payload<=1048576,'Inventory payload unavailable')
  local rows,slots,ids,head={},{},{},nil
  for record in payload:gmatch('[^;]+')do
   local v={};for x in(record..','):gmatch('(.-),')do v[#v+1]=x end
   assert(v[2]==string.format('%.0f',address),'Snapshot inventory mismatch')
   if v[1]=='I'then
    assert(not head,'Duplicate snapshot header');head={capacity=tonumber(v[3]),used=tonumber(v[4])}
    assert(integer(head.capacity,0,4096)and integer(head.used,0,head.capacity),'Invalid inventory header')
   elseif v[1]=='S'then
    assert(head and #rows<4096,'Invalid snapshot ordering')
    local slot,count=tonumber(v[3]),tonumber(v[6]);local entity,database=v[4],v[5]
    assert(integer(slot,0,head.capacity-1)and not slots[slot]and integer(count,1,2147483647),'Invalid inventory slot')
    assert(entity:match('^[1-9]%d*$')and database:match('^[1-9]%d*$')and #entity<=20 and #database<=20 and token(v[9]),'Invalid item identity')
    local key=entity..':'..database;assert(not ids[key],'Duplicate item identity');ids[key]=true;slots[slot]=true
    rows[#rows+1]={key=key,entity=entity,database=database,slot=slot,count=count,template=v[9]}
   else error('Incomplete/unresolved inventory snapshot')end
  end
  assert(head and #rows==head.used,'Incomplete backpack snapshot');return rows
 end
 local function scan(origin,callback)
  local tries,first=0,nil
  local function poll()
   local ok,result,detail=pcall(function()
    local s=current(origin);local inv,c=inventory(s)
    assert(type(NBS_PadScan)=='function'and type(NBS_InventoryChecksum)=='function','Exact backpack reader/checksum unavailable in this Lua state')
    local sum,busy=NBS_InventoryChecksum(inv:GetAddress(),c:GetAddress());assert(integer(sum,0,4294967295)and busy==0,'Backpack checksum unavailable/busy')
    first=first or sum;assert(first==sum,'Backpack changed while reading')
    local payload,missing,state=NBS_PadScan(inv:GetAddress())
    if state=='scanning'then return nil,'pending'end
    assert(state~='off'and missing==0,'Backpack read incomplete')
    local rows=parse(payload,inv:GetAddress());local after,b=NBS_InventoryChecksum(inv:GetAddress(),c:GetAddress())
    assert(after==sum and b==0,'Snapshot checksum changed')
    return {rows=rows,checksum=sum,address=inv:GetAddress()}
   end)
   if not ok then callback(nil,tostring(result));return end
   if detail=='pending'then
    tries=tries+1;if tries>=40 then callback(nil,'Backpack scan timeout');return end
    local scheduled,t=pcall(function()return app:defer(250,poll)end);if not scheduled or not t then callback(nil,'Backpack scan scheduler unavailable')end
   else callback(result)end
  end
  poll()
 end
 function self:inspect_items(done)
  return async(function(finish)
   local origin=capture();scan(origin,function(snapshot,why)
    if not snapshot then finish(false,{error=why,unsupported=true});return end
    finish(true,{context=origin.key,snapshot=snapshot,rows=snapshot.rows})
   end)
  end,done)
 end
 local function matches(snapshot,wanted)
  local n=0;for _,row in ipairs(snapshot.rows)do local v=wanted[row.key];if not v or v.template~=row.template or v.count~=row.count then return false end;n=n+1 end
  local expected=0;for _ in pairs(wanted)do expected=expected+1 end;return n==expected
 end
 function self:deposit_items(selection,id,done)
  return async(function(finish)
   assert(type(selection)=='table'and #selection>=1 and #selection<=64,'Select 1 to 64 exact backpack instances')
   local catalog=dofile(root..'/Scripts/data/catalog.lua');local origin=capture();local lines,items,total,seen={},{},0,{}
   for _,v in ipairs(selection)do
    assert(type(v)=='table'and token(v.itemId)and catalog.items[v.itemId],'Unknown deposit item')
    assert(catalog.items[v.itemId].nativeId,'Virtual-only item cannot be deposited')
    assert(type(v.entity)=='string'and type(v.database)=='string'and v.entity:match('^[1-9]%d*$')and v.database:match('^[1-9]%d*$'),'Exact entity/database required')
    local key=v.entity..':'..v.database
    assert(not seen[key]and integer(v.slot,0,4095)and integer(v.observedCount,1,2147483647)and integer(v.quantity,1,v.observedCount),'Invalid exact selection')
    assert(integer(v.inventory,1)and integer(v.checksum,0,4294967295),'Observed inventory/checksum required')
    seen[key]=true;local uid=math.tointeger(tonumber(v.database));assert(uid and uid>0 and tostring(uid)==v.database,'Database id cannot be represented exactly')
    lines[#lines+1]={key=key,entity=v.entity,database=v.database,uid=uid,slot=v.slot,before=v.observedCount,quantity=v.quantity,itemId=v.itemId,template=catalog.items[v.itemId].nativeId,inventory=v.inventory,checksum=v.checksum}
    items[v.itemId]=(items[v.itemId]or 0)+v.quantity;total=total+v.quantity
   end
   local old=start(id,'items.deposit',total,origin.key)
   if old then assert(encode_items(items)==encode_items(old.items),'Receipt item selection differs');finish(true,receipt(old));return end
   scan(origin,function(initial,why)
    if not initial then finish(false,{error=why,unsupported=true});return end
    local prepared,problem=pcall(function()
     for _,line in ipairs(lines)do
      assert(line.inventory==initial.address and line.checksum==initial.checksum,'Selection snapshot expired')
      local found;for _,v in ipairs(initial.rows)do if v.key==line.key then found=v end end
      assert(found and found.slot==line.slot and found.count==line.before and found.template:lower()==line.template:lower(),'Selected instance changed')
      line.template=found.template
     end
    end)
    if not prepared then finish(false,{error=tostring(problem)});return end
    local wanted={};for _,v in ipairs(initial.rows)do wanted[v.key]={template=v.template,count=v.count}end
    local r={id=id,context=origin.key,kind='items.deposit',amount=total,before=total,after=0,items=items}
    local saved,err=pcall(append,r,'intent');if not saved then self.blocked='Inventory journal write failed';finish(false,{error=tostring(err),review=true});return end
    local index=1
    local function step()
     scan(origin,function(snapshot,why)
      if not snapshot then review(r,finish,why);return end
      local ran,err=pcall(function()
       assert(matches(snapshot,wanted),'Backpack changed during deposit')
       local line=lines[index]
       if not line then append(r,'confirmed');finish(true,receipt(r));return end
       local live;for _,v in ipairs(snapshot.rows)do if v.key==line.key then live=v end end
       assert(live and live.count==line.before and live.template==line.template,'Exact item identity changed')
       local s=current(origin);local inv=inventory(s);assert(inv:GetAddress()==initial.address,'Backpack changed')
       local cls=signature('/Script/DuneSandbox.InventoryActionDeleteItem',{{'ObjectProperty','m_Inventory'},{'IntProperty','m_ItemIndex'},{'StructProperty','m_ItemDatabaseId'},{'IntProperty','m_Quantity'},{'EnumProperty','m_ItemAddReason'},{'StrProperty','m_ItemAddDetails'},{'UInt32Property','m_InventoryChecksum'}})
       signature('/Script/DuneSandbox.PlayerActionSystemHandler:ServerPerformAction',{{'StructProperty','ActionPayLoad'}})
       assert(native('/Script/DuneSandboxCore.EInventoryItemAddReason'):GetNameByValue(31):ToString()=='EInventoryItemAddReason::Landsraad','Verified deletion reason changed')
       local handler=s.controller.m_ActionHandler;assert(valid(handler),'Action handler unavailable')
       local action=StaticConstructObject(cls,handler,0,64);assert(valid(action),'Exact-delete action unavailable')
       action.m_Instigator=s.controller;action.m_bIsListenAction=false;action.m_bIsRequestWithCallback=true;action.m_bForceDebugActionsCheat=false
       action.m_Inventory=inv;action.m_ItemIndex=live.slot;action.m_ItemDatabaseId.UID=line.uid;action.m_Quantity=line.quantity
       action.m_ItemAddReason=31;action.m_ItemAddDetails='Endgame Overhaul deposit '..id;action.m_InventoryChecksum=snapshot.checksum
       assert(action.m_ItemDatabaseId.UID==line.uid and action.m_Quantity==line.quantity and action.m_ItemIndex==live.slot and action.m_InventoryChecksum==snapshot.checksum and action.m_Inventory:GetAddress()==initial.address,'Exact action readback failed')
       local nextWanted={};for k,v in pairs(wanted)do nextWanted[k]={template=v.template,count=v.count}end
       if live.count==line.quantity then nextWanted[line.key]=nil else nextWanted[line.key].count=live.count-line.quantity end
       -- Persist exact identity/quantity/checksum BEFORE this one native action.
       local detail=assert(io.open(root..'/inventory-details.tsv','ab'),'Cannot persist item intent')
       local wrote=detail:write(table.concat({id,index,line.entity,line.database,live.slot,line.template,line.quantity,snapshot.checksum},'\t')..'\n')
       local flushed=detail:flush();local closed=detail:close();assert(wrote and flushed and closed,'Cannot persist exact item intent')
       handler:ServerPerformAction({m_ActionMessage=action})
       local tries=0
       local function poll()
        scan(origin,function(after,why)
         if not after then review(r,finish,why);return end
         if matches(after,nextWanted)then wanted=nextWanted;index=index+1;step();return end
         tries=tries+1
         if not matches(after,wanted)or tries>=12 then review(r,finish,'Exact item delta uncertain; no repeat');return end
         local ok,t=pcall(function()return app:defer(250,poll)end);if not ok or not t then review(r,finish,'Item receipt scheduler unavailable')end
        end)
       end
       local ok,t=pcall(function()return app:defer(250,poll)end);if not ok or not t then review(r,finish,'Item receipt scheduler unavailable')end
      end)
      if not ran then review(r,finish,err)end
     end)
    end
    step()
   end)
  end,done)
 end
 function self:withdraw_items(itemId,quantity,id,done)
  return async(function(finish)
   assert(token(id),'Invalid operation id')
   assert(integer(quantity,1,2147483647),'Withdrawal requires a positive whole quantity')
   local catalog=dofile(root..'/Scripts/data/catalog.lua')
   local item=assert(catalog.items[itemId],'Unknown warehouse item')
   local code=item.nativeId and 'inventory_grant_unproven'or'virtual_item_has_no_native_template'
   -- Deliberately no native call: a count-only cheat grant has no proven
   -- fit/drop receipt; the richer API requires an unverified item-info struct.
   finish(false,{id=id,itemId=itemId,nativeId=item.nativeId,quantity=quantity,code=code,
    error=item.nativeId and 'Physical withdrawal is blocked: arbitrary item-info construction and fit/no-drop receipt are not proven; no items sent'
     or'This virtual item has no native template; no physical withdrawal is available',
    unsupported=true,review=false,items={}})
  end,done)
 end
 function self:status()
  local profile,why=self:profile_context()
  return{busy=self.busy,review=self.blocked,identitySupported=self.identityProvider~=nil or(profile and profile.manual==true)or false,
   profile=profile,profileError=why,inventorySupported=type(NBS_PadScan)=='function'and type(NBS_InventoryChecksum)=='function',
   inventoryWithdrawSupported=false,inventoryWithdrawBlocker='inventory_grant_unproven'}
 end
 return self
end
return M
