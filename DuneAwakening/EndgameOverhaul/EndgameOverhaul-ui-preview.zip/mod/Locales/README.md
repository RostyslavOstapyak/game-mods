# UI language

The initial native UMG build uses Ukrainian. Catalog names use name_uk, then name_en, then stable ID. Status translations are presentation-only in Scripts/ui/presentation.lua; durable core states are never translated or rewritten. An English UI pack is not claimed in this development version.
