local M={}
function M.attach(ui)
 local P,C=ui.P,ui.C
 local function copy(t)local r={};for k,v in pairs(t or{})do r[k]=v end;return r end
 local function fingerprint(q)
  local a={tostring(q.total),tostring(q.duration),tostring(q.warning),tostring(q.error)}
  for _,key in ipairs({'inputs','outputs','breakdown'})do for _,r in ipairs(P.rows(q[key]))do a[#a+1]=key..tostring(r.id)..tostring(r.value)end end
  return table.concat(a,'|')
 end
 function ui:form(title,action,payload,fields)
  if self.modal then return end
  local w=math.min(900,self.W-90);local h=math.min(self.H-80,760);local x=(self.W-w)/2;local y=(self.H-h)/2
  local overlay=self:make('CanvasPanel');self:put(self.content,overlay,0,0,self.W,self.H)
  local blocker=self:make('Border');blocker:SetBrushColor(C.bg);self:put(overlay,blocker,0,0,self.W,self.H)
  self:fill(overlay,x,y,w,h,C.panel)
  self:label(overlay,title,x+24,y+18,w-150,40,25,C.gold)
  local form={action=action,payload=copy(payload),fields={},overlay=overlay,title=title,buttonStart=#self.buttons+1}
  self.modal=form
  self:button(overlay,'Закрити',x+w-130,y+18,106,36,function()self:render()end)
  local scroll=self:make('ScrollBox');self:put(overlay,scroll,x+24,y+77,w-48,h-370)
  local flow=self:make('VerticalBox');scroll:AddChild(flow)
  for _,spec in ipairs(fields)do
   local def=spec;local size=self:make('SizeBox');size:SetHeightOverride(80);local slot=flow:AddChildToVerticalBox(size);slot:SetPadding({Left=0,Top=0,Right=8,Bottom=8})
   local r=self:make('CanvasPanel');size:AddChild(r);self:label(r,def.label,0,0,w-100,27,17,C.muted)
   local value=form.payload[def.key];if value==nil then value=def.default end
   if def.choices then
    local index=1;for i,c in ipairs(def.choices)do if c[1]==value then index=i end end
    local field={spec=def,index=index};form.fields[#form.fields+1]=field
    local button;button=self:button(r,def.choices[index][2],0,30,w-110,38,function()
     field.index=field.index%#def.choices+1;button:GetChildAt(0):SetText(FText(def.choices[field.index][2]));form.quote=nil
    end);field.widget=button
   else
    form.fields[#form.fields+1]={spec=def,widget=self:input(r,value,0,30,w-110,38)}
   end
  end
  local quoteScroll=self:make('ScrollBox');self:put(overlay,quoteScroll,x+24,y+h-275,w-48,185)
  form.previewSize=self:make('SizeBox');form.previewSize:SetWidthOverride(w-76);form.previewSize:SetHeightOverride(185);quoteScroll:AddChild(form.previewSize)
  local quoteCanvas=self:make('CanvasPanel');form.previewSize:AddChild(quoteCanvas)
  form.preview=self:label(quoteCanvas,'Перевірте параметри та запросіть кошторис.',0,0,w-80,185,17,C.muted)
  self:button(overlay,'Кошторис',x+24,y+h-70,210,44,function()self:quoteForm()end)
  form.confirm=self:button(overlay,'Підтвердити',x+w-260,y+h-70,236,44,function()self:submitForm()end,true)
  form.confirm:SetIsEnabled(false)
  for i=form.buttonStart,#self.buttons do self.buttons[i].modal=true end
 end
 function ui:formPayload()
  local f=self.modal;local p=copy(f.payload);local signature={}
  for _,field in ipairs(f.fields)do
   local def=field.spec;local value
   if def.choices then value=def.choices[field.index][1]
   else value=self:inputText(field.widget);if def.number then
    local normalized=value:gsub('%s',''):gsub(',','.')
    value=tonumber(normalized)
    assert(value and value==value and value~=math.huge and value~=-math.huge,'Вкажіть число: '..def.label)
    if def.integer~=false then assert(value%1==0,'Потрібне ціле число: '..def.label)end
    if def.min then assert(value>=def.min,'Значення замале: '..def.label)end
   end end
   p[def.key]=value;signature[#signature+1]=def.key..'='..tostring(value)
  end
  return p,table.concat(signature,'|')
 end
 function ui:pollForm()
  local f=self.modal;if not f or not f.confirm then return end
  local ok,_,signature=pcall(function()return self:formPayload()end)
  if not ok or(f.signature and signature~=f.signature)then f.quote=nil;f.confirm:SetIsEnabled(false)end
 end
 function ui:quoteForm()
  local f=self.modal;local ok,p,signature=pcall(function()return self:formPayload()end)
  if not ok then f.preview:SetText(FText(P.error(p)));return end
  local called,q=pcall(function()return self.service:quote(f.action,p)end)
  if not called then q={ok=false,error=P.error(q)}end
  q=q or{ok=false,error='Кошторис недоступний.'};f.quote=q.ok and q or nil;f.signature=signature
  f.confirm:SetIsEnabled(q.ok==true and not(self.data.state.nativePending or self.data.needs_review))
  local lines={q.ok and('Разом: '..P.number(q.total)..' ¤')or tostring(q.error or'Дію відхилено.')}
  if q.duration then lines[#lines+1]='Тривалість: '..P.duration(q.duration)end
  if q.inputs then lines[#lines+1]='Витрати: '..P.goods(self.data,q.inputs)end
  if q.outputs then lines[#lines+1]='Результат: '..P.goods(self.data,q.outputs)end
  for _,r in ipairs(P.rows(q.breakdown))do lines[#lines+1]=tostring(r.id)..': '..P.number(r.value)end
  if q.warning then lines[#lines+1]=tostring(q.warning)end
  local height=math.max(185,#lines*48)
  f.previewSize:SetHeightOverride(height);f.preview.Slot:SetSize({X=math.min(900,self.W-90)-80,Y=height})
  f.preview:SetText(FText(table.concat(lines,'\n')));f.fingerprint=fingerprint(q)
 end
 function ui:submitForm()
  local f=self.modal;if not f or not f.quote then return end
  local p,signature=self:formPayload();if signature~=f.signature then self:quoteForm();return end
  local q=self.service:quote(f.action,p)
  if not q.ok or fingerprint(q)~=f.fingerprint then self:quoteForm();return end
  f.confirm:SetIsEnabled(false);f.quote=nil
  local result=self.service:dispatch(f.action,p)
  if result and result.ok then
   if f.action=='inventory.deposit'then self.inventory=nil;self.page='storage'end
   self.message=result.pending and'Операцію передано. Очікуємо підтвердження; повтор недоступний.'or'Дію виконано.';self:render()
  else f.preview:SetText(FText(tostring(result and result.error or'Дія не повернула підтвердження.')))end
 end
 function ui:inspectInventory()
  if self.scanning then return end
  if self.data.unavailable or self.data.state.nativePending or self.data.needs_review then self:notice('Спершу виберіть профіль і дочекайтеся завершення попередньої операції.');return end
  if not self.service.inspect_items then self:notice('Зчитування рюкзака недоступне у фасаді.');return end
  self.scanning=true;self:notice('Читання конкретних комірок рюкзака…')
  local opened=self.handle;local context=self.data.context
  local ok,err=pcall(function()self.service:inspect_items(function(success,result)
   self.scanning=false
   if self.handle~=opened or not self.handle then return end
   if not success then self:notice(type(result)=='table'and(result.error or result.message)or tostring(result));return end
   if self:snapshot().context~=context then self:notice('Профіль змінився. Прочитайте рюкзак заново.');return end
   self.inventory=result;self.page='inventory';self.pageIndex=1;self:render()
  end)end)
  if not ok then self.scanning=false;self:notice(P.error(err))end
 end
 function ui:inventoryScreen(s)
  self:card('Внесення з рюкзака','Оберіть конкретну комірку. Після кожної операції перечитайте рюкзак.',{{'Перечитати',function()self:inspectInventory()end},{'До складу',function()self:showPage('storage')end}})
  local inventory=self.inventory;if not inventory then return end
  local matched={}
  for _,row in ipairs(inventory.rows or{})do
   for id,item in pairs(s.catalog.items)do if item.nativeId and tostring(item.nativeId):lower()==tostring(row.template):lower()then
    matched[#matched+1]={id=row.key or row.slot,row=row,itemId=id};break
   end end
  end
  self:paginate(matched,function(entry)
   local row=entry.row;local snapshot=inventory.snapshot or{}
   self:card(P.item(s,entry.itemId),'Комірка '..tostring(row.slot)..' · Наявно: '..P.number(row.count),{{'Внести',function()
    self:form('Внести: '..P.item(s,entry.itemId),'inventory.deposit',{},{{key='quantity',label='Кількість з цієї комірки',number=true,min=1,default=1}})
    -- Scope exact identity transformation to this modal, never replace another instance.
    self.modal.exact={itemId=entry.itemId,entity=row.entity,database=row.database,slot=row.slot,observedCount=row.count,inventory=snapshot.address,checksum=snapshot.checksum}
   end}},144)
  end)
 end
 -- Exact selection is prepared before both quote and dispatch.
 local basePayload=ui.formPayload
 function ui:formPayload()
  local p,signature=basePayload(self)
  if self.modal.exact then
   assert(p.quantity<=self.modal.exact.observedCount,'Кількість перевищує вміст комірки.')
   local row=copy(self.modal.exact);row.quantity=p.quantity;p={selection={row}}
  end
  return p,signature
 end
end
return M
