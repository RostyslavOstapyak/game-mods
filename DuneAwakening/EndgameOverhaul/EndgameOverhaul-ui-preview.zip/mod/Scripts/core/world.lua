local M={}
function M.attach(E,U)
 local C=E.config
 local function site(p)local s=E.state.sites[p.siteId or p.id];assert(s,'Виберіть точку.');return s end
 local function crew(p)local c=E.state.crews[p.crewId or p.id];assert(c,'Бригада не знайдена.');return c end
 local function equipmentFactor(resource)
  local item=E.catalog.items[resource]or{};local tier=E.state.equipment
  local eq=E.catalog.equipment[tier]or E.catalog.equipment[tostring(tier)]or{}
  local factors=eq.oreFactors or{};return factors[resource]or(item.tier and math.max(.125,1/(2^math.max(0,item.tier-tier)))or 1)
 end
 function E:queueShipment(spec)
  self.state.shipments=self.state.shipments or{}
  if spec.kind=='sale'then
   for _,job in pairs(self.state.shipments)do
    if job.kind=='sale'and job.offerId==spec.offerId and job.status=='queued'and job.fixedPrice==spec.fixedPrice then job.quantity=job.quantity+spec.quantity;job.remaining=job.remaining+spec.quantity;return job end
   end
  end
  spec.id=self:id('shipment');spec.remaining=spec.quantity;spec.dispatched=0;spec.delivered=0;spec.inflight=0;spec.status='queued';spec.ready=self.state.clock+(spec.delay or(spec.kind=='sale'and C.saleBatchSeconds or 0))
  self.state.shipments[spec.id]=spec;return spec
 end
 local originalReserved=E.reserved
 function E:reserved(id,exclude)
  local n=originalReserved(self,id,exclude)
  for _,job in pairs(self.state.shipments or{})do
   if(job.kind=='sale'or job.kind=='quest')and job.itemId==id and job.status~='cancelled'and job.status~='complete'then n=n+job.remaining end
  end
  return n
 end
 E:register('crew.hire',function(p,dry)
  local n=U.count(E.state.crews);assert(n<E:limit(C.crewLevels,'mining'),'Потрібен вищий рівень репутації для наступної бригади.')
  local price=C.crewPrice+C.crewStep*math.max(0,n-1)
  if dry then return{total=price,outputs={crews=1}}end
  E:spend(price);local id=E:id('crew');E.state.crews[id]={id=id,status='idle'};return E.state.crews[id]
 end)
 E:register('crew.equipment',function(p,dry)
  local tier=E.state.equipment+1;assert(tier<=6,'Досягнуто максимальне ручне обладнання.')
  assert(E:level('mining')>=(C.equipmentLevels[tier+1]or 50),'Обладнання ще не відкрите за репутацією.')
  local eq=E.catalog.equipment[tier]or E.catalog.equipment[tostring(tier)]or{};local price=eq.price or 500000*2^(tier-1)
  if dry then return{total=price,outputs={equipment=tier}}end
  E:spend(price);E.state.equipment=tier;return{tier=tier}
 end)
 E:register('transport.expand',function(p,dry)
  local count=U.count(E.state.boats);local maximum=1+math.floor((E:level('transport')-1)/4)
  assert(count<maximum,'Наступний борт ще не відкритий репутацією перевізників.')
  local price=C.boatPrice+C.boatStep*math.max(0,count-1)
  if dry then return{total=price,outputs={boats=1}}end
  E:spend(price);local id=E:id('boat');E.state.boats[id]={id=id,status='idle'};return E.state.boats[id]
 end)
 E:register('search.group',function(p,dry)
  assert(E.state.searchGroups<E:limit(C.searchGroupLevels,'researchers'),'Потрібна вища репутація дослідників.')
  local price=C.searchGroupPrice+C.searchGroupStep*(E.state.searchGroups-1)
  if dry then return{total=price,outputs={groups=1}}end;E:spend(price);E.state.searchGroups=E.state.searchGroups+1;return{groups=E.state.searchGroups}
 end)
 E:register('search.start',function(p,dry)
  assert(E.state.created,'Спочатку відкрийте підприємство.')
  local count=0;for _,j in pairs(E.state.searches)do if j.status=='running'then count=count+1 end end
  assert(count<E.state.searchGroups,'Усі пошукові групи зайняті.')
  local probe=p.probe==true;assert(not probe or E:level('researchers')>=C.probeUnlock,'Запуск зонда ще недоступний.')
  local resource=p.resource or'any';assert(resource=='any'or E.catalog.items[resource],'Невідомий ресурс.')
  local minTier=U.integer(p.minTier or 1,1,5);local price=probe and C.probePrice or C.searchPrice
  local budget=U.number(p.budget or price,price,C.maxCash)
  if dry then return{total=price,duration=C.searchSeconds,warning='Пошук не гарантує знахідку. Час до бурі враховується при автоматичному повторенні.'}end
  E:spend(price);local id=E:id('search');local j={id=id,status='running',resource=resource,minTier=minTier,probe=probe,kind=p.kind or'ore',auto=p.auto==true,budget=budget-price,paid=price,attempt=1,finish=E.state.clock+C.searchSeconds}
  E.state.searches[id]=j;return j
 end)
 E:register('search.cancel',function(p,dry)
  local j=E.state.searches[p.id or p.searchId];assert(j,'Пошук не знайдений.');if dry then return{total=0}end
  j.auto=false;j.stopRequested=true;return j
 end)
 E:register('site.clear',function(p,dry)
  local s=site(p);assert(s.danger and not s.job,'Точка не потребує нової зачистки.')
  local funding=U.number(p.funding or 1,.5,3);local price=U.money(C.clearancePrice*funding);local duration=C.clearanceSeconds/funding/(1+.1*(E.state.pmcEquipment or 0))
  if dry then return{total=price,duration=duration,warning=funding<1 and'Недофінансування знижує шанс успіху; провал зменшить репутацію.'or nil}end
  E:spend(price);s.job={kind='clear',finish=E.state.clock+duration,started=E.state.clock,duration=duration,cost=price,funding=funding};s.status='clearing';return s
 end)
 E:register('site.research',function(p,dry)
  local s=site(p);assert(not s.danger,'Спочатку потрібна зачистка ПВК.');assert(not s.job,'На точці вже працює команда.')
  assert(s.status~='mining'and s.status~='returning'and s.status~='transferred'and s.status~='lost','Ця точка недоступна для дослідження.')
  local attempts=s.researchAttempts or 0;local price=U.money(C.researchPrice*1.2^attempts)
  if dry then return{total=price,duration=C.researchSeconds,warning=s.kind=='station'and'Перше дослідження дає пропозицію технології, повторні мають менший шанс.'or nil}end
  E:spend(price);s.job={kind='research',finish=E.state.clock+C.researchSeconds,started=E.state.clock,duration=C.researchSeconds,cost=price};s.status='researching';return s
 end)
 E:register('technology.buy',function(p,dry)
  local s=site(p);local reward=s.reward;assert(reward and not reward.bought and reward.expires>E.state.clock,'Пропозиція технології недоступна.')
  if reward.type=='recipe'then
   assert(E.catalog.recipes[reward.recipeId],'Креслення відсутнє в каталозі.')
   if dry then return{total=reward.price,outputs={license=reward.recipeId}}end
   E:spend(reward.price);E.state.licenses[reward.recipeId]=true;reward.bought=true;return reward
  end
  if dry then return{total=reward.price,outputs={[reward.type..':'..reward.tier]=1}}end
  E:spend(reward.price);local key=reward.type..':'..reward.tier;E.state.technologies[key]=(E.state.technologies[key]or 0)+1;reward.bought=true;return reward
 end)
 local function miningQuote(p)
  local s=site(p);assert(s.kind=='ore'and not s.danger and(s.status=='ready'or s.status=='paused'),'Потрібне розвідане безпечне родовище.')
  local team=U.integer(p.team or 1,1,C.teamMax);assert(team==1 or E:level('mining')>=C.teamUnlock,'Збільшена команда ще не відкрита.')
  local chosen=p.crewId and E.state.crews[p.crewId]
  if not chosen then for _,c in ipairs(U.sorted(E.state.crews))do if c.status=='idle'then chosen=c;break end end end
  assert(chosen and chosen.status=='idle','Немає вільної найнятої бригади.')
  local amount=U.integer(p.quantity or s.remaining,1,2147483647);assert(s.infinite or amount<=s.remaining,'На родовищі недостатньо ресурсу.')
  local discount=E:level('mining')>=C.teamUnlock and .5*(E:level('mining')-C.teamUnlock)/(50-C.teamUnlock)or 0
  local unit=C.workPerOre*(1+(C.teamGrowth^(team-1)-1)*(1-discount))
  local rate=C.miningCycleYield*60*team*equipmentFactor(s.itemId)*(1+.2*(E:level('mining')-1)/49)
  return s,chosen,{total=U.money(amount*unit+math.ceil(amount/C.cargoCapacity)*C.flightPrice),breakdown={work=U.money(amount*unit),delivery=math.ceil(amount/C.cargoCapacity)*C.flightPrice,unit=unit,discount=discount},duration=amount/rate*3600+C.flightSeconds*2,rate=rate,quantity=amount,team=team,unit=unit}
 end
 E:register('site.mine',function(p,dry)
  local s,c,q=miningQuote(p);if dry then return q end
  -- Jobs are paid per actual extracted cycle, not an upfront debit of the entire quote.
  assert(E.state.cash>=q.unit*math.min(q.quantity,C.miningCycleYield*q.team),'Недостатньо коштів для першого циклу.')
  s.status='mining';s.crewId=c.id;s.order={quantity=q.quantity,remaining=q.quantity,mined=0,team=q.team,unit=q.unit,elapsed=0};s.buffer=s.buffer or 0;s.pickedUp=s.pickedUp or 0;s.delivered=s.delivered or 0
  c.status='travelling';c.siteId=s.id;c.arrive=E.state.clock+C.flightSeconds;return s
 end)
 E:register('site.protect',function(p,dry)
  local s=site(p);assert(s.status~='lost'and s.status~='transferred'and not s.protected,'Захист недоступний.')
  if dry then return{total=C.protectionPrice,warning='Захист збільшує шанс пережити бурю, але не гарантує збереження.'}end
  E:spend(C.protectionPrice);s.protected=true;E:xp('engineers',10);return s
 end)
 E:register('site.restore',function(p,dry)
  local s=site(p);assert(s.status=='buried'and not s.restoreAttempted,'Відновлення недоступне.')
  if dry then return{total=C.restorePrice,duration=C.searchSeconds,warning='Спроба може не повернути доступ до родовища.'}end
  E:spend(C.restorePrice);s.restoreAttempted=true;s.job={kind='restore',finish=E.state.clock+C.searchSeconds};return s
 end)
 E:register('site.transfer',function(p,dry)
  local s=site(p);assert(E:level('mining')>=C.informationUnlock,'Передача родовищ відкриється пізніше.')
  assert(s.kind=='ore'and not s.order and not s.transferred and s.status~='lost'and s.status~='buried','Цю точку не можна передати.')
  local rewardKey=s.searchId or s.id
  local reward=not E.state.searchRewards[rewardKey]and math.min(C.informationReward,(s.searchCost or C.searchPrice)*.5)or 0
  if dry then return{total=0,outputs={reward=reward},warning='Передача остаточна. Руда поступово з’являтиметься на ринку; власного доступу до точки більше немає.'}end
  E:cash(reward);E.state.searchRewards[rewardKey]=true;s.transferred=true;s.status='transferred';s.npcElapsed=0
  E.state.npcQueue[#E.state.npcQueue+1]=s.id;E:event('Передано відомості. Родовище постачатиме торговий ринок.','research');return{reward=reward,siteId=s.id}
 end)
 E:register('operation.cancel',function(p,dry)
  local s=site(p);assert(s.order or s.job,'Немає активної операції.');if dry then return{total=0,warning='Вже виконана робота оплачена; команда повертається.'}end
  if s.job then local j=s.job;local progress=U.clamp((E.state.clock-(j.started or E.state.clock))/(j.duration or 1),0,1);if j.cost then E:cash(j.cost*(1-progress))end;s.job=nil end
  if s.order then s.order.remaining=0;s.status='returning';local c=E.state.crews[s.crewId];if c then c.status='returning';c.arrive=E.state.clock+C.flightSeconds end else s.status=s.known and'ready'or'lead'end
  return s
 end)
 E:register('site.archive',function(p,dry)
  local s=site(p);assert(not s.job and not s.order and(s.buffer or 0)==0 and(s.reservedPickup or 0)==0,'Спочатку завершіть роботи та заберіть вантаж.')
  assert(s.status=='lost'or s.status=='depleted'or s.status=='buried','Архівуються лише втрачені, вичерпані або засипані точки.')
  for _,f in pairs(E.state.flights)do local job=E.state.shipments and E.state.shipments[f.jobId];assert(not job or job.siteId~=s.id or f.status=='complete'or f.status=='cancelled','Рейс цієї точки ще не завершений.')end
  if dry then return{total=0,warning='Точку буде остаточно прибрано; відновлення стане недоступним.'}end
  E.state.sites[s.id]=nil;E:event('Прибрано точку з журналу: '..s.id,'research');return{id=s.id}
 end)
 local function discover(search)
  if U.count(E.state.sites)>=C.maxSites then search.status='paused';search.reason='Журнал точок заповнений.';return false end
  local candidates={};for id,item in pairs(E.catalog.items)do if item.kind=='ore'and(search.resource=='any'or search.resource==id)then candidates[#candidates+1]=id end end;table.sort(candidates)
  if #candidates==0 and search.kind~='station'then return false end
  local kind=search.kind=='station'and'station'or'ore'
  local tier=math.floor(E:random()*4)+1;local infinite=kind=='ore'and E:random()<C.infiniteChance;if infinite then tier=5 end
  local itemId=kind=='ore'and candidates[math.floor(E:random()*#candidates)+1]or nil
  if tier<search.minTier then
   local j=E.state.journal;j[#j+1]={kind=kind,itemId=itemId,tier=tier,time=E.state.clock};while #j>C.searchJournalLimit do table.remove(j,1)end;return false
  end
  local volume=C.discoveryVolumes[math.min(tier,#C.discoveryVolumes)]
  local id=E:id('site');E.state.sites[id]={id=id,name=(kind=='ore'and'Родовище 'or'Станція ')..id,kind=kind,itemId=itemId,tier=tier,remaining=volume,initial=volume,infinite=infinite,status='lead',known=false,danger=E:random()<.2,buffer=0,delivered=0,searchId=search.id..'-'..search.attempt,searchCost=search.paid,found=E.state.clock}
  E:event('Знайдено нову точку: '..id,'research');return true
 end
 local function storm()
  local date=os.date('%Y-%m-%d');if date==E.state.stormDate then return end
  E.state.stormDate=date;E:event('Буря: оновлено цикл пустелі. Запаси заводу збережені.','storm')
  for _,s in pairs(E.state.sites)do
   if s.status=='transferred'then s.status='lost';s.remaining=0 end
   if s.status~='lost'and s.status~='depleted'and s.status~='transferred'then
    local survived=s.protected and E:random()<C.protectionChance
    if not survived then
     if s.job and s.job.cost then local progress=U.clamp((E.state.clock-(s.job.started or E.state.clock))/(s.job.duration or 1),0,1);E:cash(s.job.cost*(1-progress))end
     s.job=nil;s.buffer=0;s.order=nil;s.status='buried';s.protected=false
     local c=E.state.crews[s.crewId];if c and c.status~='idle'then c.status='returning';c.arrive=E.state.clock+C.flightSeconds end
    else s.protected=false end
   end
  end
 end
 local function finishJobs()
  for _,s in pairs(E.state.sites)do
   local j=s.job
   if j and j.finish<=E.state.clock then
    s.job=nil
    if j.kind=='clear'then
     local success=E:random()<C.clearanceChance*math.min(1,j.funding)
     if success then s.danger=false;s.status=s.known and'ready'or'lead';E:xp('pmc',30);E:event('ПВК забезпечила доступ до '..s.id,'clearance')
     else s.status=s.known and'ready'or'lead';if j.funding<1 then local f=E.state.factions.pmc;f.xp=math.max(0,f.xp-30);f.level=U.level(f.xp,100,50)end;E:event('Зачистка не вдалася: '..s.id,'warning')end
    elseif j.kind=='research'then
     local attempts=s.researchAttempts or 0;s.researchAttempts=attempts+1;s.known=true;s.status='ready';E:xp('researchers',15)
     if s.kind=='station'then
      if attempts==0 or E:random()<.5^attempts then
       local tier=math.min(5,1+math.floor((E:level('researchers')-1)/15));s.reward={type=E:random()<.5 and'speed'or'yield',tier=tier,price=C.blueprintPrice*2^(tier-1),expires=E.state.clock+86400,bought=false}
       local locked={};for id,r in pairs(E.catalog.recipes)do if r.license and not E.state.licenses[id]then locked[#locked+1]=id end end;table.sort(locked)
       if #locked>0 and E:random()<.5 then
        local id=locked[math.floor(E:random()*#locked)+1];local r=E.catalog.recipes[id]
        s.reward={type='recipe',recipeId=id,name=r.name_uk,price=C.blueprintPrice*2^((r.minTier or 1)-1),expires=E.state.clock+86400,bought=false}
       end
       E:event('Знайдено технологію на '..s.id,'technology')
      else E:event('Повторне дослідження без нової технології.','research')end
     else E:event('Підтверджено ресурс і обсяг '..s.id,'research')end
    elseif j.kind=='restore'then
     if E:random()<C.restoreChance then s.status=s.known and'ready'or'lead';E:xp('researchers',10);E:event('Відновлено доступ до '..s.id,'research')
     else s.status='lost';s.remaining=0;E:event('Родовище остаточно втрачено: '..s.id,'warning')end
    end
   end
  end
 end
 local function mining(dt)
  for _,c in pairs(E.state.crews)do
   local s=c.siteId and E.state.sites[c.siteId]
   if c.status=='travelling'and c.arrive<=E.state.clock then c.status='working'end
   if c.status=='returning'and c.arrive<=E.state.clock then c.status='idle';c.siteId=nil end
   if c.status=='working'and s and s.order then
    local order=s.order;order.elapsed=order.elapsed+dt
    local duration=C.miningCycle/(1+.2*(E:level('mining')-1)/49)
    if order.elapsed>=duration then
     local q=math.min(order.remaining,math.floor(C.miningCycleYield*order.team*equipmentFactor(s.itemId)))
     if not s.infinite then q=math.min(q,s.remaining)end
     if q>0 and s.buffer+q<=C.cargoCapacity*2 and E.state.cash>=q*order.unit then
      E:spend(q*order.unit);order.elapsed=order.elapsed-duration;order.remaining=order.remaining-q;order.mined=order.mined+q;s.buffer=s.buffer+q
      if not s.infinite then s.remaining=s.remaining-q end
      E:xp('mining',q/1000);E.state.statistics.mined=E.state.statistics.mined+q;s.reason=nil;E.dirty=true
     elseif q>0 then order.elapsed=duration;s.reason=E.state.cash<q*order.unit and'Бракує коштів.'or'Очікує вивезення.'end
     if order.remaining<=0 or(not s.infinite and s.remaining<=0)then c.status='returning';c.arrive=E.state.clock+C.flightSeconds;s.status='returning'end
    end
   end
   if c.status=='working'and(not s or not s.order)then c.status='returning';c.arrive=E.state.clock+C.flightSeconds end
  end
 end
 local function jobsReady(job)
  local available=job.remaining-(job.dispatched or 0)
  if job.status~='queued'or available<=0 or job.ready>E.state.clock then return false end
  if job.kind=='sale'then return true end
  return true
 end
 local function deliver(f)
  local job=E.state.shipments[f.jobId];if not job then return end
  local q=f.quantity
  if job.kind=='purchase'then
   local o=E.state.storage.incoming[job.orderId];assert(o,'Incoming reservation missing.');o.remaining=o.remaining-q
   if o.water then E.state.water.quantity=E.state.water.quantity+q else E:put(job.itemId,q)end
   if o.remaining<=0 then E.state.storage.incoming[o.id]=nil end
  elseif job.kind=='mining'then
   local s=E.state.sites[job.siteId];if s then s.delivered=(s.delivered or 0)+q end;E:put(job.itemId,q)
  elseif job.kind=='sale'then E:saleDelivered({itemId=job.itemId,offerId=job.offerId,quantity=q,fixedPrice=job.fixedPrice})
  elseif job.kind=='quest'then E:questDelivered({itemId=job.itemId,questId=job.questId,quantity=q})end
  job.delivered=job.delivered+q;job.inflight=job.inflight-1
  if job.remaining<=0 and job.inflight==0 then job.status='complete'end
  E:xp('transport',q/10000);E:event('Доставлено '..q..' '..job.itemId,'delivery')
 end
 local function transport()
  E.state.shipments=E.state.shipments or{}
  for _,s in pairs(E.state.sites)do
   if s.order and(s.status=='mining'or s.status=='returning')then
    local available=(s.buffer or 0)-(s.reservedPickup or 0)
    if available>=C.cargoCapacity or(s.order.remaining<=0 and available>0)then
     local quantity=math.min(C.cargoCapacity,available);s.reservedPickup=(s.reservedPickup or 0)+quantity
     E:queueShipment({kind='mining',siteId=s.id,itemId=s.itemId,quantity=quantity,prepaid=false})
    end
   end
  end
  for _,boat in pairs(E.state.boats)do
   local f=boat.flightId and E.state.flights[boat.flightId]
   if f and f.arrive<=E.state.clock then
    local job=E.state.shipments[f.jobId]
    if f.phase=='outbound'then
     local q=f.quantity
     if job.kind=='mining'then
      local s=E.state.sites[job.siteId]
      if not s or(s.buffer or 0)<q then
       job.status='cancelled';job.dispatched=math.max(0,(job.dispatched or 0)-q);job.inflight=math.max(0,job.inflight-1);boat.status='idle';boat.flightId=nil;f.status='cancelled'
       if s then s.reservedPickup=math.max(0,(s.reservedPickup or 0)-q)end
      else s.buffer=s.buffer-q;s.reservedPickup=math.max(0,(s.reservedPickup or 0)-q);s.pickedUp=(s.pickedUp or 0)+q end
     elseif job.kind=='sale'or job.kind=='quest'then
      assert(E:stock(job.itemId)>=q,'Reserved shipment inventory unavailable.');E.state.storage.items[job.itemId]=E:stock(job.itemId)-q
     end
     if f.status~='cancelled'then job.remaining=job.remaining-q;job.dispatched=math.max(0,(job.dispatched or 0)-q);f.phase='return';f.depart=E.state.clock;f.arrive=E.state.clock+C.flightSeconds end
    else
     local space=E:space();local water=job.kind=='purchase'and E.state.storage.incoming[job.orderId]and E.state.storage.incoming[job.orderId].water
     if job.kind=='mining'and space< f.quantity*(E:item(job.itemId).volume or 1)then f.status='unloading';f.arrive=E.state.clock+5
     else deliver(f);f.status='complete';boat.status='idle';boat.flightId=nil end
    end
   end
   if boat.status=='idle'then
    for _,job in ipairs(U.sorted(E.state.shipments))do if jobsReady(job)then
     local quantity=math.min(C.cargoCapacity,job.remaining-(job.dispatched or 0))
     if job.prepaid or E.state.cash>=C.flightPrice then
      if not job.prepaid then E:spend(C.flightPrice)end
      local id=E:id('flight');E.state.flights[id]={id=id,jobId=job.id,boatId=boat.id,quantity=quantity,itemId=job.itemId,phase='outbound',status='flying',depart=E.state.clock,arrive=E.state.clock+C.flightSeconds}
      boat.status='flying';boat.flightId=id;job.inflight=job.inflight+1;job.dispatched=(job.dispatched or 0)+quantity
      if job.kind=='sale'then job.ready=E.state.clock+C.saleBatchSeconds end;break
     end
    end end
   end
  end
  for _,s in pairs(E.state.sites)do if s.status=='returning'and(s.buffer or 0)==0 and(s.reservedPickup or 0)==0 then
   local c=E.state.crews[s.crewId];local inFlight=false
   for _,f in pairs(E.state.flights)do local job=E.state.shipments[f.jobId];if job and job.siteId==s.id and f.status~='complete'and f.status~='cancelled'then inFlight=true end end
   if not inFlight and(not c or c.status=='idle')then s.order=nil;s.crewId=nil;s.status=not s.infinite and s.remaining<=0 and'depleted'or'ready'end
  end end
  local completed={};for _,f in pairs(E.state.flights)do if f.status=='complete'or f.status=='cancelled'then completed[#completed+1]=f end end
  table.sort(completed,function(a,b)return a.id<b.id end);while #completed>30 do E.state.flights[table.remove(completed,1).id]=nil end
  local old={};for _,j in pairs(E.state.shipments)do if j.status=='complete'or j.status=='cancelled'then old[#old+1]=j end end
  table.sort(old,function(a,b)return a.id<b.id end);while #old>30 do E.state.shipments[table.remove(old,1).id]=nil end
 end
 local function npc(dt)
  local worked=0
  for _,id in ipairs(E.state.npcQueue)do
   local s=E.state.sites[id]
   if s and s.status=='transferred'and(s.infinite or s.remaining>0)and worked<C.npcWorkers then
    worked=worked+1;local m=E:marketItem(s.itemId)
    local exact=C.npcMiningRate*dt/3600+(s.npcRemainder or 0)
    local amount=math.floor(math.min(exact,s.infinite and math.huge or s.remaining,math.max(0,m.capacity-m.stock)))
    s.npcRemainder=exact%1
    if amount>0 then m.stock=m.stock+amount;if not s.infinite then s.remaining=s.remaining-amount end end
   end
  end
 end
 local function starter()
  if E.state.starterQuestCreated then return end
  local selected=E.catalog.recipes[C.starterLicense]
  local key=C.starterLicense
  if not selected then for _,id in ipairs({'make_pump','make_machinery'})do if E.catalog.recipes[id]then key=id;selected=E.catalog.recipes[id];break end end end
  if not selected then return end
  local product;for id in pairs(selected.outputs or{})do product=id;break end;if not product then return end
  E.state.starterQuestCreated=true
  local id=E:id('quest');local item=E:item(product)
  E.state.quests[id]={id=id,faction='mining',license=key,itemId=product,quantity=C.starterQuestQuantity,delivered=0,status='offered',urgent=false,expires=E.state.clock+864000,duration=864000,price=(item.sellPrice or item.basePrice or 1)*1.1,pendingBonus=0,xpBonus=50}
 end
 E.tickers[#E.tickers+1]=function(dt)
  if not E.state.created then return end
  storm();finishJobs();mining(dt);transport();npc(dt);starter()
  for _,s in pairs(E.state.searches)do if s.status=='running'and s.finish<=E.state.clock then
   local found=false
   for _=1,s.probe and C.probePoints or 1 do if E:random()<C.searchChance then found=discover(s)or found end end
   E:xp('researchers',10)
   local cost=s.probe and C.probePrice or C.searchPrice
   local secondsToMidnight=86400-(tonumber(os.date('%H'))*3600+tonumber(os.date('%M'))*60+tonumber(os.date('%S')))
   if not found and s.auto and not s.stopRequested and s.budget>=cost and E.state.cash>=cost and secondsToMidnight>C.searchSeconds then
    E:spend(cost);s.budget=s.budget-cost;s.attempt=s.attempt+1;s.paid=cost;s.finish=E.state.clock+C.searchSeconds
   else s.status=found and'complete'or'empty';E:event(found and'Пошук завершено зі знахідкою.'or'Пошук завершено без потрібної знахідки.','research')end
  end end
  local old={};for _,s in pairs(E.state.searches)do if s.status=='complete'or s.status=='empty'then old[#old+1]=s end end
  table.sort(old,function(a,b)return a.id<b.id end);while #old>20 do E.state.searches[table.remove(old,1).id]=nil end
 end
end
return M
