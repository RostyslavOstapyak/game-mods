param([Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$GameRoot)
$ErrorActionPreference = 'Stop'
if (Get-Process -Name 'CrimeBoss*' -ErrorAction SilentlyContinue) { throw 'Close Crime Boss before replacing the loader.' }
$bin = Join-Path $GameRoot 'CrimeBoss\Binaries\Win64'
$mods = Join-Path $bin 'ue4ss\Mods'
if (!(Test-Path -LiteralPath (Join-Path $bin 'ue4ss\UE4SS.dll'))) { throw 'UE4SS is required. See README.' }
if ((Get-FileHash -LiteralPath (Join-Path $bin 'CrimeBoss-Win64-Shipping.exe')).Hash -ne 'BA3FC33EADE72E89293A13E6FCC549F4C765098AD1B66F5D73E39AEDF3A3BDF9') { throw 'Unsupported executable. This package was tested with Steam build 25106786.' }
$target = Join-Path $mods 'ObjectiveHighlight'
$backup = Join-Path $PSScriptRoot ('backups\' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
$config = Join-Path $mods 'mods.txt'
if (Test-Path -LiteralPath $config) { Copy-Item -LiteralPath $config -Destination $backup }
if (Test-Path -LiteralPath $target) { Copy-Item -LiteralPath $target -Destination $backup -Recurse }
New-Item -ItemType Directory -Path (Join-Path $target 'Scripts') -Force | Out-Null
foreach ($name in @('main.lua','runtime.lua','probe-typed.lua')) {
    Copy-Item -LiteralPath (Join-Path $PSScriptRoot "ObjectiveHighlight\Scripts\$name") -Destination (Join-Path $target "Scripts\$name") -Force
}
$lines = if (Test-Path -LiteralPath $config) { @(Get-Content -LiteralPath $config) } else { @() }
$lines = @($lines | Where-Object { $_ -notmatch '^\s*ObjectiveHighlight\s*:' })
$lines += 'ObjectiveHighlight : 1'
[IO.File]::WriteAllLines($config, $lines, [Text.UTF8Encoding]::new($false))
Write-Output ('ObjectiveHighlight installed. Backup: ' + $backup)
