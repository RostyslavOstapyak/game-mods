local M={}
function M.fresh(config,context)
 local factions={};for _,id in ipairs({'mining','researchers','pmc','transport','engineers','trade','bank'})do factions[id]={id=id,xp=0,level=1,trust=true,commission=.10}end
 return {schema=1,context=context,sequence=0,created=false,cash=0,clock=0,seed=104729,
  storage={capacity=0,items={},reserved={},incoming={},expansions=0},
  water={quantity=0,capacity=0,tanks={}},factory={area=0,expansions=0},
  lines={},sites={},crews={},flights={},boats={},offers={},market={},quests={},technologies={},
  licenses={},events={},factions=factions,searches={},searchGroups=1,equipment=0,
  nativeJournal={},bankJournal={},nativePending=nil,needs_review=nil,
  searchRewards={},npcQueue={},journal={},stormDate=os.date('%Y-%m-%d'),
  lastQuestRefresh=0,lastMarketTick=0,lastTrend=0,statistics={earned=0,spent=0,produced=0,sold=0,mined=0},
 }
end
function M.open(app,config,util)
 local store,issue=app:data('enterprise',{version=1,defaults={profiles={}}})
 assert(store,issue and issue.message or'Cannot open persistent enterprise state.')
 local status=store:status();assert(status.state~='invalid'and status.state~='read_failed',status.error or'Invalid enterprise save.')
 local self={store=store,profiles=store:get('profiles')or{}}
 function self:load(key)
  assert(type(key)=='string'and #key>0 and #key<=512,'Character/world identity unavailable.')
  local state=self.profiles[key]
  if not state then state=M.fresh(config,key)end
  assert(state.schema==1,'Save schema unsupported; preserve the file for migration.')
  if state.nativePending then state.needs_review='Unfinished native transfer '..tostring(state.nativePending.id)..'. Manual reconciliation required.'end
  return util.copy(state)
 end
 function self:save(state)
  assert(util.allFinite(state),'State contains invalid numeric values.')
  assert(state.cash>=0 and state.cash<=config.maxCash,'Enterprise cash is outside safe bounds.')
  local previous=self.profiles[state.context];self.profiles[state.context]=util.copy(state)
  local ok,err=self.store:set('profiles',self.profiles)
  if ok then ok,err=self.store:save()end
  if not ok then self.profiles[state.context]=previous;error(err and err.message or'Cannot persist enterprise state.')end
  return true
 end
 return self
end
return M
