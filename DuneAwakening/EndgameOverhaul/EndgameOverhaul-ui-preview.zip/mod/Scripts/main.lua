-- Bootstrap only. No developer hot reload and no startup economic mutations.
local DIR=debug.getinfo(1,'S').source:sub(2):gsub('\\','/'):match('^(.*)/[^/]+$')
local ROOT=DIR..'/..'
local config=dofile(ROOT..'/config.lua')
local Framework=require('../../WPS_Framework/Scripts/api')
local app=Framework.new{id='EndgameOverhaul',version=config.version}
local lifetime={active=true,lastEconomicTick=0}
-- Retain the application, registrations and UMG handles for the mod lifetime.
EndgameOverhaulRuntime={app=app,lifetime=lifetime}
local runtime=EndgameOverhaulRuntime
local function report(message)
 print('[EndgameOverhaul] '..tostring(message)..'\n')
end
local function start()
 local ready,why=pcall(function()
  runtime.catalog=dofile(DIR..'/data/catalog.lua')
  runtime.adapter=dofile(DIR..'/game_adapter.lua').new(app,ROOT)
  runtime.service=dofile(DIR..'/core/engine.lua').new(app,runtime.catalog,config,runtime.adapter,ROOT)
  runtime.panel=dofile(DIR..'/ui/panel.lua').new(app,runtime.service,ROOT)
  runtime.terminal=dofile(DIR..'/ui/terminal.lua').new(app,function()return runtime.panel end,ROOT)
 end)
 if not ready then lifetime:cancel();report('Initialization stopped: '..tostring(why));return end
 local function tick()
  if not lifetime.active then return end
  local wall=os.time()
  if wall-lifetime.lastEconomicTick>=config.tickSeconds then
   lifetime.lastEconomicTick=wall
   local ok,err=pcall(function()runtime.service:tick()end)
   if not ok then runtime.service.notice='Стан підприємства потребує перевірки: '..tostring(err);report(err)end
  end
  local ok,err=pcall(function()runtime.panel:tick()end)
  if not ok then report(err);pcall(function()runtime.panel:close()end)end
  lifetime.timer=app:defer(runtime.panel:is_open()and 16 or 250,tick)
 end
 lifetime.timer=app:defer(1,tick)
 report('Source alpha loaded. Build an Endgame terminal and use its displayed interaction key. No offline simulation.')
end
function lifetime:cancel()
 self.active=false
 if self.timer then pcall(function()self.timer:cancel()end)end
 if runtime.escape then pcall(function()runtime.escape:cancel()end)end
 if runtime.terminal then pcall(function()runtime.terminal:cancel()end)end
 if runtime.startup then pcall(function()runtime.startup:cancel()end)end
 if runtime.panel then pcall(function()runtime.panel:close()end)end
 if runtime.service and runtime.service.state and not runtime.service.state.nativePending then
  pcall(function()runtime.service.persistence:save(runtime.service.state)end)
 end
end
runtime.startup=app:retry{interval_ms=500,max_attempts=120,probe=function()return app:ready()end,on_ready=start}
