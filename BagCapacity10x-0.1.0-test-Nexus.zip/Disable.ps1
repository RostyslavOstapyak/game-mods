param([Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$GameRoot)
$ErrorActionPreference = 'Stop'
if (Get-Process -Name 'CrimeBoss*' -ErrorAction SilentlyContinue) { throw 'Close Crime Boss first.' }
$config = Join-Path $GameRoot 'CrimeBoss\Binaries\Win64\ue4ss\Mods\mods.txt'
$lines = @(Get-Content -LiteralPath $config | Where-Object { $_ -notmatch '^\s*BagCapacity10x\s*:' })
$lines += 'BagCapacity10x : 0'
[IO.File]::WriteAllLines($config, $lines, [Text.UTF8Encoding]::new($false))
Write-Host 'BagCapacity10x disabled. Original capacity returns on next launch.'
