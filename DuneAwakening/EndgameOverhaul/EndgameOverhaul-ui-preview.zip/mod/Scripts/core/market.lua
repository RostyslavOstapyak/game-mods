local M={}
function M.attach(E,U)
 local C=E.config
 function E:marketItem(id)
  local item=self:item(id);local m=self.state.market[id]
  if not m then m={id=id,itemId=id,stock=C.marketStock,capacity=C.marketStock,sold=0,purchased=0,saturation=0,trend=1,history={},demand=item.baseDemand or C.demandBase};self.state.market[id]=m end
  return m,item
 end
 function E:price(id,side)
  local m,item=self:marketItem(id);local base=item.basePrice or item.sellPrice or 1
  local bid=math.max(.01,(item.sellPrice or base)*m.trend/(1+m.saturation/C.saturationScale))
  if side=='sell'then return U.money(bid)end
  local commission=.10-.08*(self:level('trade')-1)/49
  local scarce=(1-U.clamp(m.stock/math.max(1,m.capacity),0,1))^4
  return U.money(math.max(bid*1.02,(item.buyPrice or base)*(1+commission)*(1+scarce)*m.trend))
 end
 local function allowed(item)
  local level=E:level('trade')
  assert(item.kind~='final'and item.kind~='clean','Ці вироби не продаються цим постачальником.')
  if item.kind=='component'then assert(level>=C.intermediateBuyUnlock,'Постачання компонентів ще не відкрите.')
  elseif item.kind=='metal'or item.kind=='chemical'or item.kind=='spice'then assert(level>=C.metalBuyUnlock,'Постачання перероблених матеріалів ще не відкрите.')end
 end
 local function purchase(p,dry,special)
  assert(E.state.created,'Потрібно відкрити підприємство.');local id=p.itemId or p.id;local item=E:item(id)
  local quantity=U.integer(p.quantity,1,2147483647)
  if item.kind=='water'or id=='water'then
   local incoming=0;for _,o in pairs(E.state.storage.incoming)do if o.water then incoming=incoming+o.remaining end end
   assert(E.state.water.quantity+incoming+quantity<=E.state.water.capacity,'Недостатньо місця у водосховищі.')
  else allowed(item);local free=E:space();assert(quantity*(item.volume or 1)<=free,'Недостатньо вільного складу з урахуванням резервів.')end
  local m=E:marketItem(id);local unit=item.kind=='water'and C.waterPrice or E:price(id,'buy')
  if special then
   assert(E:level('trade')>=C.specialUnlock,'Спеціальні замовлення ще недоступні.');assert(quantity>m.stock,'Спеціальне замовлення має перевищувати доступний звичайний запас.')
   unit=(item.buyPrice or item.basePrice or unit)*(1+.10-.08*(E:level('trade')-1)/49)*(1+.30*(50-E:level('trade'))/49)
  elseif item.kind~='water'then assert(quantity<=math.floor(m.stock),'У продажу недостатньо товару.')end
  local flights=math.ceil(quantity/C.cargoCapacity);local price=U.money(unit*quantity+flights*C.flightPrice)
  if dry then return{total=price,breakdown={goods=U.money(unit*quantity),delivery=flights*C.flightPrice,flights=flights,unit=unit},duration=flights*C.flightSeconds*2/math.max(1,U.count(E.state.boats)),outputs={[id]=quantity}}end
  E:spend(price);if not special and item.kind~='water'then m.stock=m.stock-quantity end
  m.purchased=m.purchased+quantity
  local order={id=E:id('purchase'),itemId=id,quantity=quantity,remaining=quantity,status='incoming',water=item.kind=='water',special=special or false}
  E.state.storage.incoming[order.id]=order
  E:queueShipment({kind='purchase',orderId=order.id,itemId=id,quantity=quantity,prepaid=true,delay=special and 1800 or 0})
  E:event('Замовлено '..quantity..' '..id..' з доставкою.','purchase');return order
 end
 E:register('market.buy',function(p,dry)return purchase(p,dry,false)end)
 E:register('market.special',function(p,dry)return purchase(p,dry,true)end)
 E:register('market.offer',function(p,dry)
  local id=p.itemId or p.id;local item=E:item(id);assert(item.kind~='water','Вода не виставляється цим товарним каналом.')
  local quantity=U.integer(p.quantity,1,2147483647);assert(E:available(id)>=quantity,'Недостатньо вільного товару.')
  local mode=p.mode=='fixed'and'fixed'or'market';local price=mode=='fixed'and U.number(p.price,.01,C.maxCash)or E:price(id,'sell')
  if dry then return{total=0,outputs={expectedRevenue=U.money(price*quantity)},duration=quantity/math.max(1,E:marketItem(id).demand)*3600,warning='Виручка орієнтовна; кошти надходять після фактичних доставок.'}end
  local offer={id=E:id('offer'),itemId=id,quantity=quantity,remaining=quantity,allocated=0,delivered=0,earned=0,mode=mode,price=price,status='active'}
  E.state.offers[offer.id]=offer;E:event('Створено пропозицію '..quantity..' '..id,'sale');return offer
 end)
 E:register('market.cancel',function(p,dry)
  local offer=E.state.offers[p.id or p.offerId];assert(offer and offer.status=='active','Активна пропозиція не знайдена.')
  if dry then return{total=0,outputs={released=offer.remaining},warning='Вже відправлений вантаж завершує погоджену доставку.'}end
  offer.status='cancelled';offer.remaining=0;return offer
 end)
 function E:saleDelivered(job)
  local m,item=self:marketItem(job.itemId);local offer=self.state.offers[job.offerId]
  local price=job.fixedPrice or self:price(job.itemId,'sell');local payout=U.money(job.quantity*price)
  self:cash(payout);m.sold=m.sold+job.quantity;m.saturation=m.saturation+job.quantity
  m.demand=(item.baseDemand or C.demandBase)+m.sold/C.demandGrowthDivisor
  self:xp('trade',job.quantity*(item.xp or 1));self.state.statistics.sold=self.state.statistics.sold+job.quantity
  if offer then offer.delivered=offer.delivered+job.quantity;offer.earned=offer.earned+payout;if offer.remaining<=0 and offer.delivered>=offer.quantity then offer.status='complete'end end
  self:event('Продано '..job.quantity..' '..job.itemId..': '..payout,'sale')
 end
 local function capabilities()
  local out={}
  for _,l in pairs(E.state.lines)do
   for id,r in pairs(E.catalog.recipes)do
    if r.family==l.family and l.tier>=(r.minTier or 1)and(not r.license or E.state.licenses[id])then
     for itemId in pairs(r.outputs or{})do if E.catalog.items[itemId]then out[itemId]=true end end
    end
   end
  end
  return out
 end
 function E:refreshQuests()
  local active=0;for _,q in pairs(self.state.quests)do if q.faction=='trade'and q.status=='offered'then active=active+1 end end
  local maximum=self:limit(C.questCountLevels,'trade');local items=capabilities();local list={};for id in pairs(items)do list[#list+1]=id end;table.sort(list)
  for _,q in pairs(self.state.quests)do if q.status=='offered'and q.expires<=self.state.clock then q.status='expired';if q.faction=='trade'then active=active-1 end end end
  if #list==0 then return end
  while active<maximum do
   local id=list[math.floor(self:random()*#list)+1];local m,item=self:marketItem(id)
   local quantity=math.max(1,math.floor(math.min(m.demand*.5,math.max(1,m.capacity-m.stock))))
   local urgent=self:level('trade')>=C.urgentUnlock and self.state.factions.trade.trust and self:random()<.3
   local q={id=self:id('quest'),faction='trade',itemId=id,quantity=quantity,delivered=0,status='offered',urgent=urgent,expires=self.state.clock+C.questRefresh,duration=urgent and C.urgentDuration or 86400,price=self:price(id,'sell')*(urgent and(1+C.urgentPriceBonus)or 1.05),pendingBonus=0}
   self.state.quests[q.id]=q;active=active+1
  end
  -- Cap old offers; accepted quests never disappear due to list refresh.
  local old={};for _,q in pairs(self.state.quests)do if q.status=='expired'or q.status=='complete'or q.status=='failed'then old[#old+1]=q end end
  table.sort(old,function(a,b)return a.id<b.id end);while #old>30 do local q=table.remove(old,1);self.state.quests[q.id]=nil end
 end
 E:register('quest.accept',function(p,dry)
  local q=E.state.quests[p.id or p.questId];assert(q and q.status=='offered','Пропозиція вже недоступна.');assert(q.expires>E.state.clock,'Пропозиція застаріла.')
  if dry then return{total=0,duration=q.duration,inputs={[q.itemId]=q.quantity}}end
  q.status='accepted';q.deadline=E.state.clock+q.duration
  if q.license then E.state.licenses[q.license]=true end;return q
 end)
 E:register('quest.complete',function(p,dry)
  local q=E.state.quests[p.id or p.questId];assert(q and q.status=='accepted','Завдання не прийняте.')
  assert(not q.deadline or E.state.clock<q.deadline,'Строк завдання минув.')
   local waiting=0;for _,job in pairs(E.state.shipments or{})do if job.questId==q.id and job.status~='complete'and job.status~='cancelled'then waiting=waiting+job.quantity-job.delivered end end
  local amount=U.integer(p.quantity or(q.quantity-q.delivered-waiting),1);assert(amount<=q.quantity-q.delivered-waiting,'Ця частина вже відправлена.')
  assert(E:available(q.itemId)>=amount,'Недостатньо доступного товару.')
  local flights=math.ceil(amount/C.cargoCapacity);local cost=flights*C.flightPrice
  if dry then return{total=cost,inputs={[q.itemId]=amount},duration=flights*C.flightSeconds*2/math.max(1,U.count(E.state.boats))}end
  E:spend(cost);E:queueShipment({kind='quest',questId=q.id,itemId=q.itemId,quantity=amount,prepaid=true});return q
 end)
 function E:questDelivered(job)
  local q=self.state.quests[job.questId];if not q then return end
  local m,item=self:marketItem(job.itemId);local base=self:price(job.itemId,'sell')
  self:cash(job.quantity*base);self:xp('trade',job.quantity*(item.xp or 1));m.sold=m.sold+job.quantity;m.saturation=m.saturation+job.quantity;m.demand=(item.baseDemand or C.demandBase)+m.sold/C.demandGrowthDivisor
  if q.status=='accepted'then
   q.delivered=q.delivered+job.quantity;q.pendingBonus=q.pendingBonus+math.max(0,q.price-base)*job.quantity
   if q.delivered>=q.quantity then
    self:cash(q.pendingBonus);q.pendingBonus=0;q.status='complete'
    self:xp(q.faction,q.faction=='trade'and q.quantity*(item.xp or 1)*(q.urgent and C.urgentBonusXP or C.questBonusXP)or(q.xpBonus or 25))
    if q.project then self.state[q.project]=(self.state[q.project]or 0)+1 end
    self:event('Виконано замовлення '..q.id,'quest')
   end
  end
 end
 E.tickers[#E.tickers+1]=function(dt)
  if not E.state.created then return end
  local now=E.state.clock
  if now-E.state.lastTrend>=C.trendSeconds then
   E.state.lastTrend=now
   for _,m in pairs(E.state.market)do m.trend=C.trendMin+E:random()*(C.trendMax-C.trendMin)end
  end
  for id,item in pairs(E.catalog.items)do
   if item.kind~='clean'and item.kind~='final'and item.kind~='water'then
    local m=E:marketItem(id);local refill=item.refillPerHour or C.marketRefillPerHour
    m.capacity=C.marketStock+math.floor(m.purchased/10);m.stock=math.min(m.capacity,m.stock+refill*dt/3600)
    m.saturation=math.max(0,m.saturation-(item.baseDemand or C.demandBase)*dt/3600)
    if now-E.state.lastMarketTick>=C.marketTick then
     m.history[#m.history+1]={time=now,price=E:price(id,'sell')};while #m.history>60 do table.remove(m.history,1)end
    end
   end
  end
  if now-E.state.lastMarketTick>=C.marketTick then
   local elapsed=now-E.state.lastMarketTick;E.state.lastMarketTick=now
   local budget={};for id,m in pairs(E.state.market)do budget[id]=m.demand*elapsed/3600+(m.matchRemainder or 0);m.matchRemainder=budget[id]%1 end
   for _,offer in ipairs(U.sorted(E.state.offers))do if offer.status=='active'and offer.remaining>0 then
    local marketPrice=E:price(offer.itemId,'sell')
    if offer.mode~='fixed'or marketPrice>=offer.price then
     local amount=math.min(offer.remaining,math.floor(budget[offer.itemId]or 0))
     if amount>0 then
      budget[offer.itemId]=budget[offer.itemId]-amount;offer.remaining=offer.remaining-amount;offer.allocated=offer.allocated+amount
      E:queueShipment({kind='sale',offerId=offer.id,itemId=offer.itemId,quantity=amount,fixedPrice=offer.mode=='fixed'and offer.price or nil,prepaid=false})
     end
    end
   end end
  end
  for _,q in pairs(E.state.quests)do
   if q.status=='accepted'and q.deadline and now>q.deadline then
    q.status='failed';q.pendingBonus=0
    if q.urgent then local faction=E.state.factions[q.faction];faction.xp=math.max(0,faction.xp-200000);faction.level=U.level(faction.xp,200000,50000);faction.trust=false;faction.recoveryXP=faction.xp+400000 end
    E:event('Завершився строк замовлення '..q.id,'warning')
   end
  end
  local trade=E.state.factions.trade;if not trade.trust and trade.xp>=(trade.recoveryXP or math.huge)then trade.trust=true;E:event('Відновлено довіру торгового союзу.','reputation')end
  if now-E.state.lastQuestRefresh>=C.questRefresh then E.state.lastQuestRefresh=now;E:refreshQuests()end
 end
end
return M
