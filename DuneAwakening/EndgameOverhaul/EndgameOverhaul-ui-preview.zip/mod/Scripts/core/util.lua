local U={}
function U.copy(t,seen)
 if type(t)~='table'then return t end
 seen=seen or{};assert(not seen[t],'Cyclic state.');seen[t]=true
 local r={};for k,v in pairs(t)do r[k]=U.copy(v,seen)end;seen[t]=nil;return r
end
function U.number(v,min,max)
 v=tonumber(v);assert(v and v==v and v~=math.huge and v~=-math.huge,'Invalid number.')
 assert(not min or v>=min,'Number below minimum.');assert(not max or v<=max,'Number above maximum.');return v
end
function U.integer(v,min,max)local n=U.number(v,min,max);assert(n%1==0,'Whole number required.');return n end
function U.money(v)return math.floor(U.number(v,0)*100+.5)/100 end
function U.clamp(v,a,b)return math.max(a,math.min(b,v))end
function U.count(t)local n=0;for _ in pairs(t or{})do n=n+1 end;return n end
function U.sorted(t)local a={};for _,v in pairs(t or{})do a[#a+1]=v end;table.sort(a,function(x,y)return tostring(x.id)<tostring(y.id)end);return a end
function U.level(xp,first,step)
 local n,total=1,0
 while n<50 do local cost=first+step*(n-1);if xp<total+cost then return n,total,cost end;total=total+cost;n=n+1 end
 return 50,total,0
end
function U.error(e)return tostring(e):gsub('^.-:%d+: ','')end
function U.allFinite(t,seen)
 seen=seen or{};if type(t)=='number'then return t==t and math.abs(t)<9007199254740991 end
 if type(t)=='table'then if seen[t]then return false end;seen[t]=true;for _,v in pairs(t)do if not U.allFinite(v,seen)then return false end end;seen[t]=nil end;return true
end
return U
