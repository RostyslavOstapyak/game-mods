local DIR=debug.getinfo(1,'S').source:sub(2):gsub('\\','/'):match('^(.*)/[^/]+$')
local U=dofile(DIR..'/util.lua')
local M={}
function M.new(app,catalog,config,adapter,root)
 local E={app=app,catalog=catalog,config=config,adapter=adapter,root=root,actions={},tickers={},notice='',wall=nil,dirty=false}
 E.persistence=dofile(DIR..'/state.lua').open(app,config,U)
 function E:id(prefix)self.state.sequence=self.state.sequence+1;return(prefix or'job')..'-'..tostring(self.state.sequence)end
 function E:random()
  self.state.seed=(self.state.seed*48271)%2147483647;return self.state.seed/2147483647
 end
 function E:event(text,kind)
  local a=self.state.events;a[#a+1]={id=self:id('event'),time=self.state.clock,text=text,kind=kind or'info'}
  while #a>self.config.maxEvents do table.remove(a,1)end;self.dirty=true
 end
 function E:cash(delta)
  local amount=U.money(self.state.cash+delta);assert(amount<=self.config.maxCash,'Cash limit reached; withdraw funds before another payout.')
  self.state.cash=amount
  local stats=self.state.statistics;if delta>0 then stats.earned=U.money(stats.earned+delta)elseif delta<0 then stats.spent=U.money(stats.spent-delta)end
 end
 function E:spend(amount)amount=U.money(amount);assert(self.state.cash>=amount,'Недостатньо коштів на рахунку підприємства.');self:cash(-amount)end
 function E:item(id)local item=self.catalog.items[id];assert(item,'Unknown item: '..tostring(id));return item end
 function E:stock(id)return self.state.storage.items[id]or 0 end
 function E:reserved(id,exclude)
  local q=0
  for _,line in pairs(self.state.lines)do if line.id~=exclude and line.cycle then q=q+(line.cycle.inputs[id]or 0)end end
  for _,offer in pairs(self.state.offers)do if offer.status=='active'then q=q+(offer.itemId==id and offer.remaining or 0)end end
  return q
 end
 function E:available(id,exclude)return math.max(0,self:stock(id)-self:reserved(id,exclude))end
 function E:space()
  local used,reserved=0,0
  for id,n in pairs(self.state.storage.items)do used=used+n*(self:item(id).volume or 1)end
  for _,order in pairs(self.state.storage.incoming)do if not order.water then reserved=reserved+(order.remaining or 0)*(self:item(order.itemId).volume or 1)end end
  for _,line in pairs(self.state.lines)do if line.cycle then reserved=reserved+(line.cycle.space or 0)end end
  return math.max(0,self.state.storage.capacity-used-reserved),used,reserved
 end
 function E:put(id,quantity)
  self:item(id);quantity=U.integer(quantity,0,2147483647)
  local free=self:space();assert(quantity*(self:item(id).volume or 1)<=free,'Недостатньо місця на складі.')
  self.state.storage.items[id]=self:stock(id)+quantity
 end
 function E:take(id,q,exclude)
  q=U.integer(q,0);assert(self:available(id,exclude)>=q,'Недостатньо доступного запасу: '..tostring(id));self.state.storage.items[id]=self:stock(id)-q
 end
 function E:usedArea()
  local n=(self.state.created and 1+(self.state.storage.expansions or 0)or 0)+#self.state.water.tanks
  for _,line in pairs(self.state.lines)do n=n+line.machines end
  return n
 end
 function E:level(id)return self.state.factions[id]and self.state.factions[id].level or 1 end
 function E:xp(id,amount)
  local f=self.state.factions[id];if not f then return end
  f.xp=f.xp+U.number(amount,0)
  local first,step=id=='trade'and 200000 or 100,id=='trade'and 50000 or 50
  local before=f.level;local threshold;f.level,threshold,f.nextXP=U.level(f.xp,first,step);f.levelXP=f.xp-threshold
  if f.level>before then self:event(id..': репутація '..f.level,'reputation')end
 end
 function E:limit(levels,faction)
  local n=0;for _,l in ipairs(levels)do if self:level(faction)>=l then n=n+1 end end;return n
 end
 function E:register(name,handler)assert(not self.actions[name],'Duplicate action '..name);self.actions[name]=handler end
 function E:ensure()
  if not self.state then return nil,'Завантажте персонажа в одиночній грі.'end
  local key=self.adapter:context_key();if not key or key~=self.state.context then return nil,'Виберіть і підтвердьте профіль поточного персонажа.'end
  if self.state.needs_review then return nil,self.state.needs_review end
  return true
 end
 function E:quote(action,payload)
  local ready,err=self:ensure();if not ready then return{ok=false,error=err}end
  if action=='bank.deposit'or action=='bank.withdraw'or action=='inventory.deposit'or action=='inventory.withdraw'then
   local ok,result=pcall(function()
    local p=payload or{};local out={total=0}
    if action:match('^bank%.')then
     local amount=U.integer(p.amount,1,1000000000);out.total=amount
     if action=='bank.withdraw'then assert(self.state.cash>=amount,'Недостатньо коштів підприємства.')
     else local balance,why=self.adapter:get_balance();assert(balance,why);assert(balance>=amount,'Недостатньо коштів у банку персонажа.');assert(self.state.cash+amount<=self.config.maxCash,'Досягнуто ліміт рахунку.')end
    elseif action=='inventory.withdraw'then
     local id=p.itemId or p.id;local q=U.integer(p.quantity,1,2147483647);assert(self:available(id)>=q,'Недостатньо товару.');out.inputs={[id]=q};out.warning='Фізична видача потребує підтримки native-адаптера.'
    else
     local total=0;assert(type(p.selection)=='table'and #p.selection>0,'Виберіть конкретні предмети рюкзака.')
     for _,row in ipairs(p.selection)do local item=self:item(row.itemId);total=total+U.integer(row.quantity,1,2147483647)*(item.volume or 1)end
     assert(total<=self:space(),'Недостатньо місця на складі.');out.outputs={storage=total}
    end
    out.ok=true;return out
   end)
   return ok and result or{ok=false,error=U.error(result)}
  end
  local fn=self.actions[action];if not fn then return{ok=false,error='Невідома дія: '..tostring(action)}end
  local ok,value=pcall(fn,payload or{},true)
  if not ok then return{ok=false,error=U.error(value)}end
  value=value or{};value.ok=true;value.total=value.total or 0;return value
 end
 function E:dispatch(action,payload)
  if action=='profile.select'then return self:select_profile(payload or{})end
  if action=='bank.deposit'or action=='bank.withdraw'or action=='inventory.deposit'or action=='inventory.withdraw'then return self:native(action,payload or{})end
  local quote=self:quote(action,payload);if not quote.ok then self.notice=quote.error;return quote end
  if self.state.nativePending then return{ok=false,error='Попереднє переміщення коштів/предметів ще виконується.'}end
  local previous=U.copy(self.state)
  local ok,value=pcall(self.actions[action],payload or{},false)
  if ok then ok,value=pcall(function()self.persistence:save(self.state);return value end)end
  if not ok then self.state=previous;self.notice=U.error(value);return{ok=false,error=self.notice}end
  self.notice='Готово';self.dirty=false;return{ok=true,data=value}
 end
 function E:native(action,p)
  local ready,err=self:ensure();if not ready then return{ok=false,error=err}end
  if self.state.nativePending then return{ok=false,error='Незавершене переміщення. Зачекайте.'}end
  local quote=self:quote(action,p);if not quote.ok then return quote end
  local previous=U.copy(self.state);local amount,itemId,quantity
  local checked,why=pcall(function()
   if action:match('^bank%.')then
    amount=U.integer(p.amount,1,1000000000)
    if action=='bank.deposit'then local b,e=self.adapter:get_balance();assert(b,e);assert(b>=amount,'Недостатньо солярісів у банку персонажа.')
    else assert(self.state.cash>=amount,'Недостатньо коштів підприємства.');self.state.cash=self.state.cash-amount end
    assert(self.state.cash+(action=='bank.deposit'and amount or 0)<=self.config.maxCash,'Corporate balance limit.')
   elseif action=='inventory.withdraw'then itemId=p.itemId or p.id;quantity=U.integer(p.quantity,1,2147483647);self:take(itemId,quantity)
   else assert(type(p.selection)=='table','Виберіть конкретні предмети з рюкзака.');assert(self:space()>0,'Склад заповнений.')end
  end)
  if not checked then self.state=previous;return{ok=false,error=U.error(why)}end
  local id=self.state.context..':'..self:id('native');local key=self.state.context
  self.state.nativePending={id=id,action=action,amount=amount,itemId=itemId,quantity=quantity,selection=p.selection,phase='prepared'}
  local saved,issue=pcall(function()self.persistence:save(self.state)end)
  if not saved then self.state=previous;return{ok=false,error=U.error(issue)}end
  local function done(ok,result)
   result=result or{}
   if not E.state or E.state.context~=key or not E.state.nativePending or E.state.nativePending.id~=id then
    E.notice='Transfer context changed; review required.';return
   end
   local committed,problem=pcall(function()
    E.state.nativePending.receipt=U.copy(result);E.state.nativePending.phase=ok and'confirmed'or(result.review and'review'or'rejected')
    E.persistence:save(E.state)
    if ok then
     assert(result.id==id and result.confirmed==true,'Native receipt identity/confirmation missing; manual reconciliation required.')
     if action=='bank.deposit'then E.state.cash=U.money(E.state.cash+amount)
     elseif action=='inventory.deposit'then
      local total=0;for nativeId,n in pairs(result.items or{})do total=total+n*(E:item(nativeId).volume or 1)end
      local free=E:space();assert(total<=free,'Received inventory exceeds reserved storage; manual reconciliation required.')
      for nativeId,n in pairs(result.items or{})do E:put(nativeId,n)end
     end
     E:event('Завершено '..action,'transfer')
    elseif result.review then E.state.needs_review=result.error or result.message or'Native transfer outcome uncertain; no automatic retry.'
    else
     if action=='bank.withdraw'then E.state.cash=E.state.cash+amount
     elseif action=='inventory.withdraw'then E.state.storage.items[itemId]=E:stock(itemId)+quantity end
    end
    E.state.nativeJournal[#E.state.nativeJournal+1]={id=id,action=action,ok=ok,review=result.review or false,time=E.state.clock,receipt=U.copy(result)}
    while #E.state.nativeJournal>40 do table.remove(E.state.nativeJournal,1)end
    if not result.review then E.state.nativePending=nil end
    E.persistence:save(E.state)
   end)
   if not committed then E.state.needs_review='Transfer persistence requires review: '..U.error(problem);E.notice=E.state.needs_review
   else E.notice=ok and'Переміщення завершено.'or(result.error or result.message or'Переміщення відхилено.')end
  end
  local invoked,problem=pcall(function()
   if action:match('^bank%.')then self.adapter:transfer(action=='bank.deposit'and'deposit'or'withdraw',amount,id,done)
   elseif action=='inventory.deposit'then self.adapter:deposit_items(p.selection,id,done)
   else self.adapter:withdraw_items(itemId,quantity,id,done)end
  end)
  if not invoked then done(false,{review=true,error=U.error(problem)})end
  return{ok=true,pending=true,id=id}
 end
 function E:inspect_items(done)return self.adapter:inspect_items(done)end
 function E:adapter_status()return self.adapter.status and self.adapter:status()or{}end
 function E:profile_context()
  local info,why=self.adapter:profile_context();if not info then return nil,why end
  info.saved={}
  for key,state in pairs(self.persistence.profiles)do
   local encoded=key:match('^manual1:(%x+)$')
   if encoded then local id=encoded:gsub('..',function(v)return string.char(tonumber(v,16))end);info.saved[#info.saved+1]={id=id,created=state.created==true}end
  end
  table.sort(info.saved,function(a,b)return a.id<b.id end);return info
 end
 function E:select_profile(p)
  if self.state and self.state.nativePending then return{ok=false,error='Спочатку потрібно завершити або звірити попереднє переміщення.'}end
  local ok,result=pcall(function()
   if self.state and self.dirty then self.persistence:save(self.state)end
   self.state=nil;self.wall=nil
   local key,why=self.adapter:select_profile(p.id or p.profileId,{confirmed=p.confirmed==true,session=p.session});assert(key,why)
   self.state=self.persistence:load(key);self.wall=os.time();self.notice='Профіль вибрано';return key
  end)
  if not ok then self.state=nil;self.adapter:clear_profile();self.notice=U.error(result);return{ok=false,error=self.notice}end
  return{ok=true,data={context=result}}
 end
 function E:snapshot()
  local profile,profileError=self:profile_context()
  local active=self.adapter:context_key()
  if not self.state or not active or active~=self.state.context then return{state=nil,catalog=self.catalog,config=self.config,now=0,notice=self.notice,context=nil,profile=profile,profileError=profileError}end
  local state=U.copy(self.state);local free,used,reserved=self:space()
  state.storage.free=free;state.storage.used=used;state.storage.reservedSpace=reserved;state.storage.reserved={}
  for id in pairs(state.storage.items)do state.storage.reserved[id]=self:reserved(id)end
  state.factory.used=self:usedArea();state.factory.free=math.max(0,state.factory.area-state.factory.used)
  for id,f in pairs(state.factions)do
   local threshold;f.level,threshold,f.nextXP=U.level(f.xp,id=='trade'and 200000 or 100,id=='trade'and 50000 or 50);f.levelXP=f.xp-threshold
   f.commission=id=='trade'and(.10-.08*(f.level-1)/49)or nil
  end
  for id,m in pairs(state.market)do m.buyPrice=self:price(id,'buy');m.sellPrice=self:price(id,'sell')end
  state.mining={equipment=state.equipment,available=self:limit(self.config.crewLevels,'mining'),hired=U.count(state.crews),occupied=0}
  for _,crew in pairs(state.crews)do if crew.status~='idle'then state.mining.occupied=state.mining.occupied+1 end end
  local checked,balance,err=pcall(function()return self.adapter:get_balance()end);state.nativeBalance=checked and balance or nil;state.nativeBalanceError=checked and err or tostring(balance)
  return{state=state,catalog=self.catalog,config=self.config,now=state.clock,notice=self.notice,needs_review=state.needs_review,context=state.context,profile=profile,profileError=profileError}
 end
 function E:tick()
  local ok,key,why=pcall(function()return self.adapter:context_key()end)
  if not ok or not key then self.wall=nil;self.notice=why or tostring(key or'Завантажте одиночну гру.');return end
  local wall=os.time()
  if not self.state or self.state.context~=key then
   if self.state and self.state.nativePending then self.wall=nil;self.notice='Завершується переміщення попереднього персонажа.';return end
   if self.state and self.dirty then self.persistence:save(self.state)end
   self.state=self.persistence:load(key);self.wall=wall;self.notice='';return
  end
  local dt=math.max(0,wall-(self.wall or wall));self.wall=wall
  if self.state.nativePending or self.state.needs_review then return end
  dt=math.min(dt,60);if dt==0 then return end
  local previous=U.copy(self.state)
  local worked,err=pcall(function()
   self.state.clock=self.state.clock+dt
   for _,fn in ipairs(self.tickers)do fn(dt)end
   assert(U.allFinite(self.state),'Invalid economic value.')
   if self.dirty or not self.lastSave or self.state.clock-self.lastSave>=10 then self.persistence:save(self.state);self.lastSave=self.state.clock;self.dirty=false end
  end)
  if not worked then self.state=previous;self.state.needs_review='Потрібна перевірка стану: '..U.error(err);self.notice=self.state.needs_review;app:log('error',self.notice)end
 end
 for _,name in ipairs({'factory','market','world','contractors'})do dofile(DIR..'/'..name..'.lua').attach(E,U)end
 return E
end
return M
