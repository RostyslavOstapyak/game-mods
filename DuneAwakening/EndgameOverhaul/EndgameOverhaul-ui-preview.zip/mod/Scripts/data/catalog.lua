-- Endgame Overhaul, independent data definitions. No game calls.
-- Prices/equipment/industrial scales are designer values, never native quotes.
local C={version=1,items={},recipes={},equipment={},defaults={maxTier=3,industrialScale=10},notes={
 prices='BALANCE-V1.3 + TRADE-XP-TABLE-V2; designer sell/buy, not native vendor prices',
 recipes='Collected external game recipes 1.5.3.7; not verified against installed build',
 metalWater='Native water removed from metal processing by mod design; cleaner consumes water separately',
 spice='Game ingredient/output batches, designer cycle times matching 200/600/1200 melange per hour',
 equipment='Copper factors from documented Cutteray index/40; other ore curves explicitly designer normalized'}}
local function item(id,uk,en,kind,base,sell,buy,xp,native,tier)
 C.items[id]={name_uk=uk,name_en=en,kind=kind,basePrice=base,sellPrice=sell,buyPrice=buy,xp=xp,
  nativeId=native,volume=1,tier=tier or 1,provenance='designer-price-v1.3'}
end
item('copper_ore','Мідна руда','Copper Ore','ore',2,1.8,3,1,'AzuriteOre',1)
item('iron_ore','Залізна руда','Iron Ore','ore',4,3.6,6,2,'MagnetiteOre',1)
item('carbon_ore','Вуглецева руда','Carbon Ore','ore',8,7.2,12,4,'DolomiteRock',1)
item('aluminum_ore','Алюмінієва руда','Aluminum Ore','ore',16,14.4,24,8,'BauxiteOre',2)
item('jasmium','Язмієвий кристал','Jasmium Crystal','ore',36,32.4,54,18,'JasmiumCrystal',2)
item('titanium_ore','Титанова руда','Titanium Ore','ore',60,54,90,30,'T6ResourceA',3)
item('erythrite','Еритритовий кристал','Erythrite Crystal','ore',3,2.7,4.5,1.5,'ErythriteCrystal',1)
item('flour_sand','Борошнистий пісок','Flour Sand','ore',.5,.45,.75,.25,'FlourSand',1)
item('basalt','Базальт','Basalt Stone','ore',2,1.8,3,1,'Basalt',1)
item('stravidium_mass','Маса стравідіуму','Stravidium Mass','ore',20,18,30,10,'T6ResourceB',3)
item('fuel_cell','Паливний елемент','Fuel Cell','ore',10,9,15,5,'Oil',1)
item('spice_sand','Спайсовий пісок','Spice Sand','ore',6,5.4,9,3,'SpiceSand',2)
item('water','Вода','Water','water',.05,0,.05,0,nil,1)
local metals={
 {'copper','Мідний злиток','Copper Ingot',20,10,'CopperBar',1},
 {'iron','Залізний злиток','Iron Ingot',45,22.5,'IronBar',1},
 {'steel','Сталевий злиток','Steel Ingot',120,60,'SteelBar',1},
 {'aluminum','Алюмінієвий злиток','Aluminum Ingot',220,110,'AluminiumBar',2},
 {'duraluminum','Дюралюмінієвий злиток','Duraluminum Ingot',550,275,'DuraluminumRod',2},
 {'plastanium','Пластанієвий злиток','Plastanium Ingot',950,475,'T6RefinedResourceA',3}}
for _,v in ipairs(metals)do item(v[1],v[2],v[3],'metal',v[4],v[4],v[4]*1.1,v[5],v[6],v[7])end
local goods={
 {'cobalt','Кобальтова паста','Cobalt Paste',40,20,'CobaltBar',1},
 {'silicone','Силіконовий блок','Silicone Block',20,10,'Silicone',1},
 {'fiber','Волокно стравідіуму','Stravidium Fiber',170,85,'T6RefinedResourceB',2},
 {'vehicle_fuel','Мала паливна каністра','Small Vehicle Fuel Cell',400,200,'FuelCanister',1},
 {'plastone','Пластон','Plastone',3.5,1.75,'Plastone',1},
 {'melange','Меланж','Spice Melange',1500,750,'MelangeSpice',1},
 {'spice_residue','Залишки спайсу','Spice Residue',2,1,'SpiceResidue',1}}
for _,v in ipairs(goods)do item(v[1],v[2],v[3],(v[1]=='melange'or v[1]=='spice_residue')and'spice'or'chemical',v[4],v[4],v[4]*1.1,v[5],v[6],v[7])end
local parts={
 {'machinery','Складні механізми','Complex Machinery',120,'T2MachineComponent',1},
 {'servoks','Просунуті сервоприводи','Advanced Servoks',120,'OldImperialComponent1',1},
 {'pump','Промисловий насос','Industrial Pump',300,'T4HarkSpiceSiloComponent1',1},
 {'actuator','Привід Гольцмана','Holtzman Actuator',200,'T1ExplorationComponent',1},
 {'plasteel','Пласталева пластина','Plasteel Plate',80,'T6PlasteelComponent',3},
 {'capacitor','Конденсатор частинок','Particle Capacitor',150,'OldImperialComponent2',1},
 {'cooler','Термоелектричний охолоджувач','Thermoelectric Cooler',400,'T5DeepDesertShieldWallComponent',2},
 {'amplifier','Променевий підсилювач','Ray Amplifier',180,'T3MiningGalleryComponent2',1},
 {'armor_plate','Бронепластина','Armor Plating',220,'T2HeavyComponent',1},
 {'diamondine','Діамантовий пил','Diamondine Dust',60,'T4MysaTarilComponent1',2},
 {'carbide','Карбідні уламки','Carbide Scraps',100,'T4MysaTarilComponent2',2},
 {'piston','Гідравлічний поршень','Hydraulic Piston',450,'T5FactionBaseComponent2',2},
 {'regulator','Військовий регулятор живлення','Military Power Regulator',500,'T5FactionBaseComponent1',2},
 {'advanced_machinery','Просунуті механізми','Advanced Machinery',700,'T6Machinery',3},
 {'advanced_pump','Ефективний промисловий насос','Fluid Efficient Industrial Pump',1380,'T6IndustrialPump',3},
 {'improved_actuator','Покращений привід Гольцмана','Improved Holtzman Actuator',1000,'T6HoltzmanActuator',3}}
for _,v in ipairs(parts)do item(v[1],v[2],v[3],'component',v[4],v[4],v[4]*1.1,v[4]/2,v[5],v[6])end
local finals={
 {'wing_mk4','Крило розвідувального орнітоптера Mk4','Scout Ornithopter Wing Mk4',4000,'OrnithopterLightLocomotion_4',2},
 {'scout_engine_mk4','Двигун орнітоптера Mk4','Scout Ornithopter Engine Mk4',13000,'OrnithopterLightEngine_4',2},
 {'buggy_engine_mk3','Двигун багі Mk3','Buggy Engine Mk3',8000,'BuggyEngine_3',1},
 {'sandcrawler_vacuum_mk6','Спайсовий пилосос Mk6','Sandcrawler Vacuum Mk6',140000,'SandcrawlerSpiceHeader_6',3}}
for _,v in ipairs(finals)do item(v[1],v[2],v[3],'final',v[4],v[4],v[4]*1.1,v[4]/2,v[5],v[6])end
local function variant(seconds,inputs,outputs,water)return{seconds=seconds,inputs=inputs,outputs=outputs,water=water or 0}end
local function recipe(id,product,family,tier,variants,license,source)
 local first=variants[tier];local it=C.items[product]
 C.recipes[id]={name_uk=it.name_uk,name_en=it.name_en,family=family,minTier=tier,seconds=first.seconds,
  inputs=first.inputs,outputs=first.outputs,water=first.water,variants=variants,license=license==true,
  provenance=source or'collected-game-recipe/designer-industrial-scale'}
end
-- Quantities x10, native per-cycle seconds retained: explicit industrial scope.
recipe('smelt_copper','copper','furnace',1,{[1]=variant(5,{copper_ore=40},{copper=10}),[2]=variant(4,{copper_ore=30},{copper=10}),[3]=variant(3,{copper_ore=20},{copper=10})})
recipe('smelt_iron','iron','furnace',1,{[1]=variant(10,{iron_ore=50},{iron=10}),[2]=variant(7,{iron_ore=40},{iron=10}),[3]=variant(5,{iron_ore=30},{iron=10})})
recipe('smelt_steel','steel','furnace',1,{[1]=variant(5,{carbon_ore=40,iron=10},{steel=10}),[2]=variant(4,{carbon_ore=30,iron=10},{steel=10}),[3]=variant(3,{carbon_ore=20,iron=10},{steel=10})})
recipe('smelt_aluminum','aluminum','furnace',2,{[2]=variant(30,{aluminum_ore=70},{aluminum=10}),[3]=variant(20,{aluminum_ore=40},{aluminum=10})})
recipe('smelt_duraluminum','duraluminum','furnace',2,{[2]=variant(5,{jasmium=40,aluminum=10},{duraluminum=10}),[3]=variant(4,{jasmium=30,aluminum=10},{duraluminum=10})})
recipe('smelt_plastanium','plastanium','furnace',2,{[2]=variant(30,{titanium_ore=60,fiber=10},{plastanium=10}),[3]=variant(20,{titanium_ore=40,fiber=10},{plastanium=10})})
recipe('make_cobalt','cobalt','chemical',1,{[1]=variant(15,{erythrite=30},{cobalt=10},750),[2]=variant(10,{erythrite=20},{cobalt=10},750),[3]=variant(10,{erythrite=20},{cobalt=10},750)})
recipe('make_silicone','silicone','chemical',1,{[1]=variant(15,{flour_sand=50},{silicone=10},500),[2]=variant(10,{flour_sand=30},{silicone=10},500),[3]=variant(10,{flour_sand=30},{silicone=10},500)})
recipe('make_fiber','fiber','chemical',2,{[2]=variant(10,{stravidium_mass=30},{fiber=10},1000),[3]=variant(10,{stravidium_mass=30},{fiber=10},1000)})
recipe('make_fuel','vehicle_fuel','chemical',1,{[1]=variant(15,{fuel_cell=250},{vehicle_fuel=10}),[2]=variant(10,{fuel_cell=200},{vehicle_fuel=10}),[3]=variant(10,{fuel_cell=200},{vehicle_fuel=10})})
recipe('make_plastone','plastone','furnace',1,{[1]=variant(15,{basalt=2000,silicone=10},{plastone=2000},500),[2]=variant(10,{basalt=2000,silicone=10},{plastone=2500},500),[3]=variant(5,{basalt=1750,silicone=10},{plastone=2500},500)})
recipe('refine_spice','melange','spice',1,{[1]=variant(18,{spice_sand=100},{melange=1,spice_residue=5},750),[2]=variant(60,{spice_sand=750},{melange=10,spice_residue=50},7000),[3]=variant(600,{spice_sand=10000},{melange=200,spice_residue=1000},75000)},false,'game-batches/designer-cycle-time')
local crafted={
 {'machinery',24,{steel=2,silicone=1},4,1}, {'servoks',12,{copper=1,cobalt=1},2,1},
 {'pump',24,{steel=2,silicone=1},2,1}, {'actuator',24,{steel=1,cobalt=1},2,1},
 {'plasteel',150,{plastanium=1,silicone=1},25,3}, {'capacitor',12,{copper=1,silicone=1},1,1},
 {'cooler',24,{aluminum=2,cobalt=1},2,2}, {'amplifier',12,{copper=1,cobalt=1},1,1},
 {'armor_plate',12,{steel=2,silicone=1},2,1}, {'diamondine',24,{carbon_ore=1,silicone=1},4,2},
 {'carbide',24,{steel=1,cobalt=1},4,2}, {'piston',48,{duraluminum=2,silicone=1},4,2},
 {'regulator',24,{duraluminum=1,cobalt=2},2,2}}
for _,v in ipairs(crafted)do
 recipe('make_'..v[1],v[1],'component',v[5],{[v[5]]=variant(v[2],v[3],{[v[1]]=v[4]})},true,'designer-component-recipe-v1.2')
end
recipe('make_advanced_machinery','advanced_machinery','component',3,{[3]=variant(3,{machinery=3,plasteel=2,cobalt=1},{advanced_machinery=1},50)},true,'collected-game-recipe')
recipe('make_advanced_pump','advanced_pump','component',3,{[3]=variant(3,{pump=3,plasteel=2,silicone=2},{advanced_pump=1},50)},true,'collected-game-recipe')
recipe('make_improved_actuator','improved_actuator','component',3,{[3]=variant(3,{actuator=3,plasteel=2,cobalt=1},{improved_actuator=1},50)},true,'collected-game-recipe')
recipe('assemble_wing','wing_mk4','final',2,{[2]=variant(20,{aluminum=7,servoks=4,cobalt=3,pump=2},{wing_mk4=1},65)},true,'collected-game-recipe')
recipe('assemble_scout_engine','scout_engine_mk4','final',2,{[2]=variant(20,{aluminum=27,cobalt=11,capacitor=4,machinery=6},{scout_engine_mk4=1},260)},true,'collected-game-recipe')
recipe('assemble_buggy_engine','buggy_engine_mk3','final',1,{[1]=variant(20,{steel=20,capacitor=8,cobalt=13,machinery=10},{buggy_engine_mk3=1},135)},true,'collected-game-recipe')
recipe('assemble_vacuum','sandcrawler_vacuum_mk6','final',3,{[3]=variant(20,{plastanium=45,servoks=27,cobalt=33,melange=42,advanced_machinery=9},{sandcrawler_vacuum_mk6=1},830)},true,'collected-game-recipe')
local cleanable={'copper_ore','iron_ore','carbon_ore','aluminum_ore','jasmium','titanium_ore'}
for _,id in ipairs(cleanable)do
 local raw=C.items[id];local clean='clean_'..id
 item(clean,'Очищена: '..raw.name_uk,'Cleaned '..raw.name_en,'clean',raw.basePrice*1.1,raw.sellPrice*1.1,raw.buyPrice*1.1,raw.xp*1.1,nil,raw.tier)
 C.items[clean].rawId=id
 recipe('clean_'..id,clean,'cleaner',1,{[1]=variant(1.2,{[id]=10},{[clean]=11},10)},false,'designer-cleaning-10-to-11')
end
-- Mining is a normalized mod cycle, not a claim about native mining units/hour.
local copper={1,1.2,1.8,2.6,3.4,4.2,5}
local prices={0,50000,100000,200000,400000,800000,1600000}
for tier=0,6 do
 local factors={}
 for id,v in pairs(C.items)do if v.kind=='ore'then
  -- Other materials use a deliberately gentler designer curve, not copper measurements.
  factors[id]=id=='copper_ore'and copper[tier+1]or(1+tier*.4)
 end end
 C.equipment[tier]={name=tier==0 and'Improvised'or('Mk'..tier),price=prices[tier+1],oreFactors=factors,
  provenance=tier==0 and'designer-baseline'or'copper-index/40; other-ores-designer-curve'}
end
C.defaults.itemOrder={'copper_ore','iron_ore','carbon_ore','aluminum_ore','jasmium','titanium_ore','erythrite','flour_sand','basalt','stravidium_mass','fuel_cell','spice_sand'}
C.defaults.nativeIdCaseInsensitive=true
return C
