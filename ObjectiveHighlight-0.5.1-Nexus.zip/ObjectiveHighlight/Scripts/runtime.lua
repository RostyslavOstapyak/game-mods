-- Revision 0.4: verified property names, no retained UObject handles, no component creation.
return function(root, events)
    local CATEGORY = 4 -- Verified enum value: VisibleThroughWalls.
    local previous = {} -- Addresses and numbers only; no live UObject handles between ticks.
    local previousMeshes = {}
    local schemas = {}
    local context = events or {serial=1, eventDriven=false}
    local cache, seenSerial, cacheMiss, compatibilityTicks = nil, nil, false, 0
    local selectorCache = {}
    local metrics = {rebuilds=0, globalSearches=0, outlineWrites=0, meshWrites=0}
    local probeTicks, probeDone = 0, false
    local timing, tickNumber = false, 0
    if root then
        local request = io.open(root .. "request-warm-timing", "r")
        if request then request:close(); os.remove(root .. "request-warm-timing"); timing = true end
    end
    local function valid(object) return object ~= nil and object:IsValid() end
    local function schema(class)
        local key = class:GetFullName()
        if schemas[key] then return schemas[key] end
        local fields = {}
        local parent = class
        while valid(parent) do
            parent:ForEachProperty(function(property)
                local name = property:GetFName():ToString()
                if fields[name] == nil then
                    if property:IsA(PropertyTypes.BoolProperty) then fields[name] = "bool"
                    elseif property:IsA(PropertyTypes.ObjectProperty) then fields[name] = "object"
                    elseif property:IsA(PropertyTypes.IntProperty) then fields[name] = "int"
                    else fields[name] = "other" end
                end
            end)
            parent = parent:GetSuperStruct()
        end
        schemas[key] = fields
        return fields
    end
    local function declaredBoolean(object, name)
        if schema(object:GetClass())[name] ~= "bool" then return nil end
        local value = object[name]
        if type(value) == "boolean" then return value end
        return nil
    end
    local function globalItem(class)
        while valid(class) do
            if class:GetFName():ToString() == "IGS_GlobalInventoryObject" then return true end
            class = class:GetSuperStruct()
        end
        return false
    end
    local kinds = {"IGS_LookAtTriggerComponent", "IGS_PickupActorInventoryItem", "IGS_ScriptActorBase", "IGS_ScriptManagerBase", "IGS_OutlineComponent"}
    local function rebuild()
        local startSerial = context.serial
        local nextCache, potentialOwners = {}, {}
        local count = 0
        for _, kind in ipairs(kinds) do
            local nodes = {}
            metrics.globalSearches = metrics.globalSearches + 1
            for _, node in ipairs(FindAllOf(kind) or {}) do
                if valid(node) and valid(node:GetWorld()) then
                    nodes[#nodes + 1] = node
                    if kind == "IGS_LookAtTriggerComponent" then
                        local owner = node:GetOwner()
                        if valid(owner) then potentialOwners[owner:GetAddress()] = true end
                    elseif kind == "IGS_PickupActorInventoryItem" then
                        potentialOwners[node:GetAddress()] = true
                    end
                end
            end
            local handles = {}
            for _, node in ipairs(nodes) do
                local include = true
                if kind == "IGS_OutlineComponent" then
                    local owner = node:GetOwner()
                    include = valid(owner) and potentialOwners[owner:GetAddress()] == true
                end
                if include then handles[#handles + 1] = node; count = count + 1 end
            end
            -- UE4SS tracks these wrappers in its deletion map. Validate on every use.
            nextCache[kind] = handles
        end
        cache, seenSerial, cacheMiss = nextCache, startSerial, false
        metrics.rebuilds = metrics.rebuilds + 1
        print("[ObjectiveHighlight] Live index rebuilt: " .. count .. " validated handles; 5 global searches.\n")
    end
    local function instances(kind)
        local result = {}
        for _, node in ipairs(cache[kind] or {}) do
            if valid(node) then result[#result + 1] = node else cacheMiss = true end
        end
        return result
    end
    local function selectedFields(class)
        local key = class:GetFullName()
        if selectorCache[key] then return selectorCache[key] end
        local result = {}
        for name, kind in pairs(schema(class)) do
            local lower = name:lower()
            local selected = lower:find("target",1,true) or lower:find("selected",1,true)
                or lower:find("correct",1,true) or lower:find("required",1,true) or lower:find("manager",1,true)
            local subject = lower:find("computer",1,true) or lower:find("terminal",1,true)
                or lower:find("item",1,true) or lower:find("object",1,true) or lower:find("actor",1,true)
            if kind == "object" and selected and subject then result[#result + 1] = name end
        end
        selectorCache[key] = result
        return result
    end
    local function collect(observe)
        local targets, clueOwners, meshes = {}, {}, {}
        local clueCount = 0
        for _, trigger in ipairs(instances("IGS_LookAtTriggerComponent")) do
            if valid(trigger) and valid(trigger:GetWorld()) and trigger.bIsEnabled then
                clueCount = clueCount + 1
                local owner = trigger:GetOwner()
                if valid(owner) then
                    clueOwners[owner:GetAddress()] = true
                    if schema(owner:GetClass()).Computer == "object" then
                        local mesh = owner.Computer
                        if valid(mesh) then
                            local fields = schema(mesh:GetClass())
                            if fields.bRenderCustomDepth == "bool" and fields.CustomDepthStencilValue == "int" then
                                meshes[owner:GetAddress()] = mesh
                            end
                        end
                    end
                    local correct = declaredBoolean(owner, "CorrectComputer")
                    if correct == nil or (correct and trigger.mR_bIsEnabledRuntime and not trigger.mR_bIsTriggered) then
                        targets[owner:GetAddress()] = "discovery clue"
                    end
                end
            end
        end
        for _, pickup in ipairs(instances("IGS_PickupActorInventoryItem")) do
            if valid(pickup) and valid(pickup:GetWorld()) and globalItem(pickup.R_ItemClassToAdd) then
                local interaction = pickup.InteractiveComponent
                if valid(interaction) and interaction.bIsEnabled and not interaction.bIsObjectiveCompleted then
                    targets[pickup:GetAddress()] = "global mission item"
                end
            end
        end
        -- Read only declared object references which the game explicitly names as selected targets.
        -- Restrict them to live discovery-clue owners; no mission names or employee identities.
        for _, kind in ipairs({"IGS_ScriptActorBase", "IGS_ScriptManagerBase"}) do
            for _, actor in ipairs(instances(kind)) do
                if valid(actor) and valid(actor:GetWorld()) then
                    for _, name in ipairs(selectedFields(actor:GetClass())) do
                            local target = actor[name]
                            if valid(target) and clueOwners[target:GetAddress()] then
                                local used = declaredBoolean(target, "AlreadyUsed")
                                if used ~= true then targets[target:GetAddress()] = "script-selected " .. name end
                            end
                    end
                end
            end
        end
        if observe and root and clueCount > 0 and not probeDone then
            probeTicks = probeTicks + 1
            if probeTicks >= 5 then
                probeDone = true
                local request = io.open(root .. "request-typed-snapshot", "r")
                if request then
                    request:close()
                    assert(loadfile(root .. "probe-typed.lua"))()(root)
                    os.remove(root .. "request-typed-snapshot")
                    os.remove(root .. "request-sdk-snapshot")
                    print("[ObjectiveHighlight] One-shot typed snapshot complete.\n")
                end
            end
        end
        return targets, meshes
    end
    local function update(clear)
        compatibilityTicks = compatibilityTicks + 1
        -- Compatibility fallback is used only until the revised loader is restarted.
        local compatibilityRefresh = not context.eventDriven and compatibilityTicks % 60 == 0
        if not cache or cacheMiss or seenSerial ~= context.serial or compatibilityRefresh then rebuild() end
        local targets, meshes = collect(not clear)
        if clear then targets = {} end
        local live, outlinedOwners = {}, {}
        for _, outline in ipairs(instances("IGS_OutlineComponent")) do
            if valid(outline) and valid(outline:GetWorld()) then
                local owner = outline:GetOwner()
                if valid(owner) then
                    outlinedOwners[owner:GetAddress()] = true
                    local address = outline:GetAddress()
                    if targets[owner:GetAddress()] then
                        if previous[address] == nil then previous[address] = outline.LocalOverrideOutlineState end
                        if outline.LocalOverrideOutlineState ~= CATEGORY then
                            outline:SetLocalOutlineCategoryState(CATEGORY, true)
                            metrics.outlineWrites = metrics.outlineWrites + 1
                        end
                        live[address] = true
                    elseif previous[address] ~= nil then
                        if outline.LocalOverrideOutlineState == CATEGORY then
                            outline:SetLocalOutlineCategoryState(CATEGORY, false)
                            if previous[address] ~= 0 then outline:SetLocalOutlineCategoryState(previous[address], true) end
                        end
                    end
                end
            end
        end
        for address in pairs(previous) do if not live[address] then previous[address] = nil end end
        -- Computers without an OutlineComponent use their existing render mesh directly.
        -- Never create new components and never invoke computer interaction/state functions.
        local liveMeshes = {}
        for ownerAddress, mesh in pairs(meshes) do
            local address = mesh:GetAddress()
            if targets[ownerAddress] and not outlinedOwners[ownerAddress] then
                if previousMeshes[address] == nil then
                    previousMeshes[address] = {depth=mesh.bRenderCustomDepth, stencil=mesh.CustomDepthStencilValue}
                    print("[ObjectiveHighlight] Direct mesh selected: " .. mesh:GetFullName() .. " via " .. targets[ownerAddress] .. "\n")
                end
                if mesh.CustomDepthStencilValue ~= CATEGORY then
                    mesh:SetCustomDepthStencilValue(CATEGORY)
                    metrics.meshWrites = metrics.meshWrites + 1
                end
                if not mesh.bRenderCustomDepth then
                    mesh:SetRenderCustomDepth(true)
                    metrics.meshWrites = metrics.meshWrites + 1
                end
                liveMeshes[address] = true
            elseif previousMeshes[address] then
                local original = previousMeshes[address]
                if mesh.CustomDepthStencilValue == CATEGORY then
                    mesh:SetCustomDepthStencilValue(original.stencil)
                    mesh:SetRenderCustomDepth(original.depth)
                end
            end
        end
        for address in pairs(previousMeshes) do if not liveMeshes[address] then previousMeshes[address] = nil end end
    end
    return {tick = function()
        tickNumber = tickNumber + 1
        local sample = timing and tickNumber >= 2 and tickNumber <= 6
        if sample then print("[ObjectiveHighlight-PROFILE] BEGIN warm_tick_" .. tickNumber .. "\n") end
        update(false)
        if sample then print("[ObjectiveHighlight-PROFILE] END warm_tick_" .. tickNumber .. "\n") end
    end, cleanup = function() update(true) end, metrics=metrics}
end
