-- Native UMG shell. Bootstrap alone advances service:tick().
local DIR=debug.getinfo(1,'S').source:sub(2):gsub('\\','/'):match('^(.*)/[^/]+$')
local P=dofile(DIR..'/presentation.lua')
local M={}
local function valid(o)return o and o:IsValid()end
local function hex(s)
 local function c(i)local v=tonumber(s:sub(i,i+1),16)/255;return v<=.04045 and v/12.92 or((v+.055)/1.055)^2.4 end
 return{r=c(1),G=c(3),B=c(5),A=1}
end
local C={bg=hex('141619'),panel=hex('1d2024'),edge=hex('393e45'),ink=hex('dedbd4'),muted=hex('afb2b7'),gold=hex('c7ac7e'),blue=hex('a2bdcd'),red=hex('dfa58f'),button=hex('292d32')}
local pages={{'overview','Огляд'},{'production','Виробництво'},{'storage','Склад і вода'},{'trade','Торговий союз'},{'researchers','Дослідники'},{'mining','Видобуток'},{'pmc','ПВК'},{'transport','Перевізники'},{'engineers','Інженери'},{'bank','Банк'},{'journal','Журнал'}}
function M.new(app,service,root)
 local self={app=app,service=service,root=root,buttons={},bindings={},page='overview',pageIndex=1,filter='',category='all',C=C,P=P}
 self.root=self.root or DIR..'/../..'
 dofile(DIR..'/forms.lua').attach(self)
 dofile(DIR..'/screens.lua').attach(self)
 function self:make(name)
  local w=StaticConstructObject(StaticFindObject('/Script/UMG.'..name),self.tree,0,0)
  assert(valid(w),'UMG unavailable: '..name);return w
 end
 function self:put(parent,w,x,y,width,height)
  local slot=parent:AddChildToCanvas(w);slot:SetPosition({X=x,Y=y});slot:SetSize({X=width,Y=height});return w
 end
 function self:fill(parent,x,y,w,h,color)
  local b=self:make('Border');b:SetBrushColor(color or C.panel);b:SetVisibility(3);return self:put(parent,b,x,y,w,h)
 end
 function self:label(parent,value,x,y,w,h,size,color,getter)
  local t=self:make('TextBlock');t:SetText(FText(tostring(value or'')));t.Font.Size=size or 18;t:SetAutoWrapText(true);t.WrapTextAt=w
  t:SetColorAndOpacity({SpecifiedColor=color or C.ink,ColorUseRule=0});t:SetVisibility(3)
  self:put(parent,t,x,y,w,h)
  if getter then self.bindings[#self.bindings+1]={widget=t,get=getter}end
  return t
 end
 function self:button(parent,title,x,y,w,h,callback,primary)
  local plate=self:fill(parent,x,y,w,h,primary and hex('48402f')or C.button)
  local b=self:make('Button');self:put(parent,b,x,y,w,h)
  for _,name in ipairs({'Normal','Hovered','Pressed','Disabled'})do b.WidgetStyle[name].DrawAs=0 end
  local t=self:make('TextBlock');t:SetText(FText(title));t.Font.Size=16;t:SetJustification(1)
  t:SetColorAndOpacity({SpecifiedColor=primary and C.gold or C.ink,ColorUseRule=0})
  local slot=b:AddChild(t);slot:SetPadding({Left=8,Top=0,Right=8,Bottom=0});slot:SetHorizontalAlignment(0);slot:SetVerticalAlignment(2)
  self.buttons[#self.buttons+1]={widget=b,callback=callback,plate=plate,primary=primary};return b
 end
 function self:input(parent,value,x,y,w,h)
  local e=self:make('EditableTextBox');e:SetText(FText(tostring(value or'')))
  e.WidgetStyle.TextStyle.Font.Size=18
  e:SetForegroundColor(C.ink);e.WidgetStyle.TextStyle.ColorAndOpacity.SpecifiedColor=C.ink
  for _,name in ipairs({'BackgroundImageNormal','BackgroundImageHovered','BackgroundImageFocused','BackgroundImageReadOnly'})do
   e.WidgetStyle[name].TintColor.SpecifiedColor=C.bg;e.WidgetStyle[name].TintColor.ColorUseRule=0
  end
  return self:put(parent,e,x,y,w,h)
 end
 function self:inputText(w)local v=w:GetText();return type(v)=='string'and v or v:ToString()end
 function self:image(parent,name,x,y,w,h)
  local ok,result=pcall(function()
   self.textures=self.textures or{}
   local texture=self.textures[name]
   if not texture then
    texture=StaticFindObject('/Script/Engine.Default__KismetRenderingLibrary'):ImportFileAsTexture2D(self.pc,self.root..'/UI/'..name)
    assert(valid(texture),'Texture unavailable: '..name)
    local holder=self:make('Image');holder:SetBrushFromTexture(texture,false);self.textureKeeper:AddChildToCanvas(holder)
    self.textures[name]=texture
   end
   local img=self:make('Image');img:SetBrushFromTexture(texture,false);img:SetColorAndOpacity({r=1,G=1,B=1,A=1});img:SetVisibility(3)
   return self:put(parent,img,x,y,w,h)
  end)
  return ok and result or nil
 end
 function self:snapshot()
  local ok,s=pcall(function()return service:snapshot()end)
  if not ok then return{state={},catalog={items={},recipes={}},notice=P.error(s),unavailable=true}end
  s=s or{};s.catalog=s.catalog or{};s.catalog.items=s.catalog.items or{};s.catalog.recipes=s.catalog.recipes or{}
  s.unavailable=s.state==nil;s.state=s.state or{};return s
 end
 function self:focusRoot()
  StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary'):SetInputMode_UIOnlyEx(self.pc,self.handle.widget,0,false)
 end
 function self:notice(message)self.message=tostring(message or'');if valid(self.noticeLabel)then self.noticeLabel:SetText(FText(self.message))end end
 function self:showPage(id)
  self.page=id;self.pageIndex=1;self.filter='';self.category='all';self:render()
 end
 function self:render()
  if not self.handle then return end
  self:focusRoot();self.buttons={};self.bindings={};self.meters={};self.modal=nil;self.content:ClearChildren()
  self.data=self:snapshot();local s=self.data;local state=s.state
  self.structure=self:structureKey(s)
  self.renderContext=s.context
  self:fill(self.content,0,0,self.W,self.H,C.bg)
  self:fill(self.content,0,0,226,self.H,hex('181b1f'))
  self:label(self.content,'ENDGAME\nOVERHAUL',22,24,190,76,25,C.gold)
  if not s.unavailable then
   for i,p in ipairs(pages)do local id=p[1];self:button(self.content,p[2],14,122+(i-1)*47,198,39,function()self:showPage(id)end,id==self.page)end
  end
  self:button(self.content,'Закрити · Esc',14,self.H-64,198,40,function()self:close()end)
  self:fill(self.content,226,0,self.W-226,83,C.panel)
  if not s.unavailable then
   self:label(self.content,'Рахунок: '..P.number(state.cash)..' ¤',252,23,440,40,22,C.gold,function(v)return 'Рахунок: '..P.number(v.state.cash)..' ¤'end)
   self:label(self.content,'Площа: '..P.number((state.factory or{}).used)..' / '..P.number((state.factory or{}).area),math.max(700,self.W-550),28,280,32,18,C.muted,function(v)local f=v.state.factory or{};return 'Площа: '..P.number(f.used)..' / '..P.number(f.area)end)
  end
  self:button(self.content,'Оновити',self.W-160,20,132,42,function()self:render()end)
  self:label(self.content,s.unavailable and 'Профіль підприємства' or self:title(),254,104,self.W-310,48,30,C.ink)
  self.noticeLabel=self:label(self.content,self.message or s.notice or'',254,self.H-67,self.W-285,52,16,C.red)
  if s.needs_review or state.nativePending then
   self:label(self.content,s.needs_review and('Потрібна звірка: '..tostring(s.needs_review))or'Нативне переміщення очікує підтвердження.',254,158,self.W-300,60,17,C.red)
  end
  self.bodyY=(s.needs_review or state.nativePending)and 227 or 170
  local scroll=self:make('ScrollBox');self:put(self.content,scroll,250,self.bodyY,self.W-274,self.H-self.bodyY-82)
  self.flow=self:make('VerticalBox');scroll:AddChild(self.flow);self.bodyWidth=self.W-294
  if s.unavailable then self:profileScreen(s);return end
  self:buildScreen(s)
 end
 function self:title()
  if self.page=='lineTech'then return 'Технології лінії'end
  if self.page=='inventory'then return 'Внесення з рюкзака'end
  for _,p in ipairs(pages)do if p[1]==self.page then return p[2]end end;return self.page
 end
 function self:structureKey(s)
  local a={tostring(s.context),tostring(s.unavailable),tostring(s.needs_review),tostring(s.state.nativePending and s.state.nativePending.id)}
  for _,key in ipairs({'lines','sites','searches','flights','crews','offers','quests','technologies','events'})do
   for _,r in ipairs(P.rows(s.state[key]))do a[#a+1]=key..tostring(r.id)..tostring(r.status)..tostring(r.value)end
  end
  return table.concat(a,'|')
 end
 function self:row(height)
  local size=self:make('SizeBox');size:SetHeightOverride(height);size:SetWidthOverride(self.bodyWidth)
  local slot=self.flow:AddChildToVerticalBox(size);slot:SetPadding({Left=0,Top=0,Right=8,Bottom=12})
  local canvas=self:make('CanvasPanel');size:AddChild(canvas)
  if not self:image(canvas,'panel.png',0,0,self.bodyWidth,height)then self:fill(canvas,0,0,self.bodyWidth,height,C.panel)end
  return canvas
 end
 function self:card(title,details,actions,height)
  actions=actions or{};height=height or(#actions>0 and 156 or 112)
  local r=self:row(height);self:label(r,title,18,12,self.bodyWidth-40,36,22,C.ink)
  self:label(r,details or'',18,50,self.bodyWidth-40,height-(#actions>0 and 104 or 58),17,C.muted)
  local x=18;for _,a in ipairs(actions)do local width=a.width or 172
   if x+width>self.bodyWidth-16 then break end
   self:button(r,a[1],x,height-48,width,35,a[2],a.primary);x=x+width+10
  end;return r
 end
 function self:meter(parent,x,y,width,getter,color)
  self:fill(parent,x,y,width,4,C.edge)
  local bar=self:fill(parent,x,y,1,4,color or C.gold)
  self.meters=self.meters or{};self.meters[#self.meters+1]={widget=bar,width=width,get=getter}
 end
 function self:action(label,action,payload,fields)
  return{label,function()self:form(label,action,payload or{},fields or{})end}
 end
 function self:paginate(rows,draw)
  local count=#rows;local pagesCount=math.max(1,math.ceil(count/30));self.pageIndex=math.min(self.pageIndex,pagesCount)
  if count==0 then self:card('Немає записів','Нові записи з’являться після відповідної дії.');return end
  for i=(self.pageIndex-1)*30+1,math.min(count,self.pageIndex*30)do draw(rows[i])end
  if pagesCount>1 then local r=self:row(56)
   self:button(r,'Назад',12,8,140,38,function()self.pageIndex=math.max(1,self.pageIndex-1);self:render()end)
   self:label(r,tostring(self.pageIndex)..' / '..pagesCount,180,14,200,28,18,C.muted)
   self:button(r,'Далі',400,8,140,38,function()self.pageIndex=math.min(pagesCount,self.pageIndex+1);self:render()end)
  end
 end
 function self:is_open()return self.handle~=nil end
 function self:open()
  if self.handle then return end
  local session=app:session();if not session.ok then return end
  self.pc=session.controller;self.pcAddress=self.pc:GetAddress()
  if self.pc.bShowMouseCursor then return end
  local ok,err=pcall(function()
   local h,issue=app:ui_create('/Script/DuneSandbox.DuneUserWidget',{z_order=950});assert(h,issue and issue.message);self.handle=h
   self.tree=h.widget.WidgetTree;h.widget:RemoveFromParent()
   local layout=StaticFindObject('/Script/UMG.Default__WidgetLayoutLibrary');local size=layout:GetViewportSize(self.pc);local dpi=layout:GetViewportScale(self.pc)
   assert(type(dpi)=='number'and dpi>0,'Viewport scale unavailable')
   local width,height=size.X/dpi,size.Y/dpi
   local factor=math.min(1,width/1280,height/800);self.W=math.min(1920,width/factor);self.H=height/factor
   local canvas=self:make('CanvasPanel');self.tree.RootWidget=canvas;self:fill(canvas,0,0,width,height,C.bg)
   self.textureKeeper=self:make('CanvasPanel');self:put(canvas,self.textureKeeper,0,0,1,1);self.textureKeeper:SetVisibility(1);self.textures={}
   local scale=self:make('ScaleBox');scale:SetStretch(2);self:put(canvas,scale,(width-self.W*factor)/2,0,self.W*factor,height)
   local sizing=self:make('SizeBox');sizing:SetWidthOverride(self.W);sizing:SetHeightOverride(self.H);scale:AddChild(sizing)
   self.content=self:make('CanvasPanel');sizing:AddChild(self.content)
   h.widget:SetDesiredSizeInViewport({X=width,Y=height});h.widget:SetAlignmentInViewport({X=0,Y=0});h.widget:SetPositionInViewport({X=0,Y=0},false);h.widget:AddToViewport(950)
   self.pc.bShowMouseCursor=true;self.pc:SetIgnoreMoveInput(true);self.pc:SetIgnoreLookInput(true);self:render()
   StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary'):SetInputMode_UIOnlyEx(self.pc,h.widget,0,false)
  end)
  if not ok then self:close();print('[EndgameOverhaul] UI: '..tostring(err)..'\n')end
 end
 function self:close()
  if not self.handle then return end
  pcall(function()
   local s=app:session();if not s.ok or s.controller:GetAddress()~=self.pcAddress then return end
   s.controller:SetIgnoreMoveInput(false);s.controller:SetIgnoreLookInput(false)
   if not valid(s.controller:GetHUD():GetActiveWindow())then s.controller.bShowMouseCursor=false;StaticFindObject('/Script/UMG.Default__WidgetBlueprintLibrary'):SetInputMode_GameOnly(s.controller,false)end
  end)
  self.handle:close();self.handle=nil;self.buttons={};self.bindings={};self.modal=nil;self.content=nil;self.tree=nil;self.textures=nil;self.textureKeeper=nil;self.inventory=nil
 end
 function self:tick()
  if not self.handle then return end
  if self.checkedAt~=os.time()then
   self.checkedAt=os.time();local session=app:session()
   if not session.ok or session.controller:GetAddress()~=self.pcAddress then self:close();return end
   if valid(session.controller:GetHUD():GetActiveWindow())then self:close();return end
   self.data=self:snapshot()
   local changed=self:structureKey(self.data)~=self.structure
   if self.data.context~=self.renderContext then
    self.inventory=nil
    if self.renderContext~=nil or self.data.unavailable then self:render();self.renderContext=self.data.context;return end
   end
   self.renderContext=self.data.context
   if changed and not self.modal then self:render();return end
   for _,b in ipairs(self.bindings)do if valid(b.widget)then local ok,value=pcall(b.get,self.data);if ok then b.widget:SetText(FText(tostring(value)))end end end
   for _,m in ipairs(self.meters or{})do if valid(m.widget)then
    local ok,value=pcall(m.get,self.data);if ok then m.widget.Slot:SetSize({X=math.max(0,math.min(1,tonumber(value)or 0))*m.width,Y=4})end
   end end
   if self.data.notice~=self.lastNotice then self.lastNotice=self.data.notice;self:notice(self.data.notice)end
  end
  if self.modal then self:pollForm()end
  for _,b in ipairs(self.buttons)do
   if valid(b.widget)and(not self.modal or b.modal)then
    local pressed=b.widget:IsPressed();local hover=b.widget:IsHovered()
    b.plate:SetBrushColor(hover and hex('3a3b3b')or(b.primary and hex('48402f')or C.button))
    if b.down and not pressed and hover then b.down=false;local ok,e=pcall(b.callback);if not ok then
     if self.modal and valid(self.modal.preview)then self.modal.preview:SetText(FText(P.error(e)))else self:notice(P.error(e))end
    end;return end
    b.down=pressed
   else b.down=false end
  end
 end
 return self
end
return M
