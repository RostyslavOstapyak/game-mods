-- One repeating callback on the game thread. No LoopAsync / ExecuteInGameThread bridge.
local root = assert(debug.getinfo(1, "S").source:sub(2):match("^(.*[/\\])"))
local currentText, controller, failed = nil, nil, false
local events = {serial=1, eventDriven=false}
local ticks = 0
local function log(s) print("[ObjectiveHighlight] " .. s .. "\n") end
if type(LoopInGameThreadWithDelay) ~= "function" then
    log("STOPPED: this UE4SS build does not expose the required game-thread timer.")
    return
end
local function changed() events.serial = events.serial + 1 end
if type(NotifyOnNewObject) == "function" and type(RegisterLoadMapPostHook) == "function" then
    for _, class in ipairs({
        "/Script/BF_FrameworkGame.IGS_LookAtTriggerComponent",
        "/Script/BF_FrameworkGame.IGS_PickupActorInventoryItem",
        "/Script/BF_FrameworkGame.IGS_ScriptActorBase",
        "/Script/BF_FrameworkGame.IGS_ScriptManagerBase"
    }) do
        -- Do not read partially constructed objects; only invalidate the path index.
        NotifyOnNewObject(class, function() changed(); return false end)
    end
    RegisterLoadMapPostHook(function() changed() end)
    events.eventDriven = true
end
local function tick()
    ticks = ticks + 1
    local ok, failure = pcall(function()
        -- Check the small development file every five ticks, not every tick.
        local text = currentText
        if currentText == nil or ticks % 5 == 0 then
            local file = assert(io.open(root .. "runtime.lua", "r"))
            text = file:read("*a"); file:close()
        end
        if text ~= currentText then
            currentText = text
            local factory = assert(load(text, "@" .. root .. "runtime.lua"))()
            assert(type(factory) == "function", "Invalid controller factory")
            local replacement = factory(root, events)
            assert(type(replacement) == "table" and type(replacement.tick) == "function", "Invalid controller")
            if controller then controller.cleanup() end
            controller, failed = replacement, false
            log("0.5.1 controller loaded; validated object cache, event-driven invalidation, change-only render updates.")
        end
        if not failed and controller then controller.tick() end
    end)
    if not ok and not failed then
        failed = true
        log("STOPPED after Lua error; controller will not repeat until its code is replaced: " .. tostring(failure))
    end
end
LoopInGameThreadWithDelay(1000, tick)
log("0.5.1 loader ready; one game-thread timer, no keyboard toggle.")
