-- Lua loader for the build-specific native capacity patch.
local source = debug.getinfo(1, "S").source
local folder = source:sub(1, 1) == "@" and source:sub(2):match("^(.*[/\\])") or nil
assert(folder, "[BagCapacity10x] Cannot locate Scripts folder")
local dll = folder .. "native/BagCapacity10x.dll"
local entry, failure = package.loadlib(dll, "luaopen_BagCapacity10x")
if not entry then
    error("[BagCapacity10x] Native module failed to load: " .. tostring(failure))
end
entry()
print("[BagCapacity10x] Native module loaded. Check Scripts/native/BagCapacity10x.log for APPLIED or REFUSED.\n")
