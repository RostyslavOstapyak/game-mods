-- Presentation helpers only; no engine state mutation.
local M={}
function M.fold(s)
 s=tostring(s):lower()
 local upper={'А','Б','В','Г','Ґ','Д','Е','Є','Ж','З','И','І','Ї','Й','К','Л','М','Н','О','П','Р','С','Т','У','Ф','Х','Ц','Ч','Ш','Щ','Ь','Ю','Я'}
 local lower={'а','б','в','г','ґ','д','е','є','ж','з','и','і','ї','й','к','л','м','н','о','п','р','с','т','у','ф','х','ц','ч','ш','щ','ь','ю','я'}
 for i,v in ipairs(upper)do s=s:gsub(v,lower[i])end
 return s
end
function M.number(v)
 if type(v)~='number' then return '—' end
 if v~=v or v==math.huge or v==-math.huge then return '—' end
 local s=tostring(math.floor(v));local sign=s:sub(1,1)=='-'and'-'or'';s=s:gsub('^-','')
 return sign..s:reverse():gsub('(%d%d%d)','%1 '):reverse():gsub('^ ','')
end
function M.duration(v)
 if type(v)~='number'then return '—'end
 v=math.max(0,math.floor(v));return string.format('%02d:%02d:%02d',math.floor(v/3600),math.floor(v/60)%60,v%60)
end
function M.rows(t)
 local out={};for k,v in pairs(t or{})do
  if type(v)=='table'then local r={};for a,b in pairs(v)do r[a]=b end;r.id=r.id or k;out[#out+1]=r
  else out[#out+1]={id=k,value=v}end
 end
 table.sort(out,function(a,b)return tostring(a.id)<tostring(b.id)end);return out
end
function M.count(t)local n=0;for _ in pairs(t or{})do n=n+1 end;return n end
local statuses={idle='Вільно',running='Працює',waiting='Очікує',paused='Призупинено',lead='Знахідка',ready='Доступно',mining='Видобуток',returning='Повернення',travelling='У дорозі',clearing='Зачистка',researching='Дослідження',buried='Засипано',lost='Втрачено',transferred='Передано',active='Активно',complete='Завершено',completed='Завершено',cancelled='Скасовано',queued='У черзі',offered='Доступне',accepted='Прийняте'}
function M.status(v)return statuses[v]or tostring(v or'—')end
function M.item(s,id)local i=(s.catalog.items or{})[id]or{};return i.name_uk or i.name_en or tostring(id or'—')end
function M.goods(s,t)
 local a={};for _,r in ipairs(M.rows(t))do a[#a+1]=M.item(s,r.id)..': '..M.number(r.value)end
 return #a>0 and table.concat(a,' · ')or'—'
end
function M.error(v)return tostring(v):gsub('^.-:%d+: ','')end
return M
