param([Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$GameRoot)
$ErrorActionPreference = 'Stop'
if (Get-Process -Name 'CrimeBoss*' -ErrorAction SilentlyContinue) { throw 'Close Crime Boss first.' }
$config = Join-Path $GameRoot 'CrimeBoss\Binaries\Win64\ue4ss\Mods\mods.txt'
Copy-Item -LiteralPath $config -Destination ($config + '.before-objective-disable-' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
$lines = @(Get-Content -LiteralPath $config | Where-Object { $_ -notmatch '^\s*ObjectiveHighlight\s*:' })
$lines += 'ObjectiveHighlight : 0'
[IO.File]::WriteAllLines($config, $lines, [Text.UTF8Encoding]::new($false))
Write-Output 'ObjectiveHighlight disabled for the next launch.'
