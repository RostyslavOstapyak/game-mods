local M={}
function M.attach(ui)
 local P=ui.P
 local function n(key,label,value,min)return{key=key,label=label,default=value or 1,number=true,min=min or 1}end
 local function choice(key,label,options,value)return{key=key,label=label,choices=options,default=value}end
 local yesno={{false,'Ні'},{true,'Так'}}
 local families={{'furnace','Плавильня'},{'chemical','Хімія'},{'component','Компоненти'},{'final','Готові вироби'},{'cleaner','Очищення'},{'spice','Спайс'}}
 local techTypes={{'speed','Швидкість'},{'yield','Вихід'}}
 local function bindCard(self,title,get,actions,height)
  local r=self:card(title,'',actions,height)
  self:label(r,get(self.data),18,50,self.bodyWidth-40,(height or 156)-104,17,self.C.muted,get)
  return r
 end
 function ui:reputation(s,id)
  local f=(s.state.factions or{})[id]or{}
  self:card('Репутація компанії','Рівень '..P.number(f.level)..' / 50 · Досвід: '..P.number(f.levelXP or f.xp)..' / '..P.number(f.nextXP)..' · Комісія: '..(f.commission and string.format('%.1f%%',f.commission*100)or'—'),nil,104)
 end
 function ui:productToolbar()
  local r=self:row(114)
  self:label(r,'Пошук за назвою або ID',14,8,400,26,17,self.C.muted)
  local search=self:input(r,self.filter,14,39,self.bodyWidth-210,36)
  self:button(r,'Знайти',self.bodyWidth-178,39,156,36,function()self.filter=P.fold(self:inputText(search));self.pageIndex=1;self:render()end)
  local cats={{'all','Усе'},{'ore','Руда'},{'metal','Метали'},{'component','Компоненти'},{'final','Вироби'},{'chemical','Хімія'}}
  local x=14;for _,c in ipairs(cats)do local id=c[1];self:button(r,c[2],x,82,135,27,function()self.category=id;self.pageIndex=1;self:render()end,self.category==id);x=x+143 end
 end
 function ui:products(s,source,draw)
  local rows={}
  for _,r in ipairs(P.rows(source))do
   local item=s.catalog.items[r.id]or{};local name=P.item(s,r.id)
   if(self.category=='all'or item.kind==self.category)and(self.filter==''or P.fold(name):find(self.filter,1,true)or tostring(r.id):lower():find(self.filter,1,true))then rows[#rows+1]=r end
  end
  self:paginate(rows,draw)
 end
 function ui:productColumns(parent,labels)
  local w=self.bodyWidth-230
  local columns={16,w*.46,w*.64,w*.82}
  for i,label in ipairs(labels)do
   local right=columns[i+1] or w-16
   self:label(parent,label,columns[i],12,right-columns[i]-8,30,15,self.C.muted)
  end
 end
 function ui:productHeader(labels)
  local row=self:row(42)
  self:fill(row,0,0,self.bodyWidth,42,self.C.panel)
  self:productColumns(row,labels)
 end
 function ui:productRow(name,values,actions)
  local w=self.bodyWidth
  local row=self:row(56)
  self:fill(row,0,0,w,54,self.C.panel)
  self:productColumns(row,{name,values[1],values[2],values[3]})
  local x=w-222
  for _,action in ipairs(actions)do
   self:button(row,action[1],x,10,104,34,action[2])
   x=x+110
  end
 end
 function ui:buildScreen(s)
  local state=s.state;local A=function(...)return self:action(...)end
  if self.page=='inventory'then self:inventoryScreen(s);return end
  if self.page=='lineTech'then self:lineTechnologyScreen(self.selectedLine);return end
  if self.page=='overview'then
   local hero=self:row(184);self:image(hero,'refinery.png',0,0,326,184)
   self:label(hero,'ПРОМИСЛОВИЙ ТЕРМІНАЛ',350,26,self.bodyWidth-375,35,21,self.C.gold)
   self:label(hero,'Виробництво, запаси та підрядники підприємства.',350,79,self.bodyWidth-375,74,22,self.C.ink)
   local factory=state.factory or{};local store=state.storage or{};local water=state.water or{}
   self:card(state.created and'Підприємство працює'or'Відкрийте підприємство',state.created and('Площа: '..P.number(factory.used)..' / '..P.number(factory.area)..' · Лінії: '..P.count(state.lines))or'Спочатку поповніть корпоративний рахунок у банку. Відкриття створить початкову лінію, склад і бак.',{state.created and A('Розширити площу','factory.expand')or A('Відкрити завод','factory.open')})
   local stocks=self:row(136)
   local half=(self.bodyWidth-12)/2
   self:fill(stocks,0,0,half,128,self.C.panel)
   self:fill(stocks,half+12,0,half,128,self.C.panel)
   self:label(stocks,'Товарний склад',16,12,half-32,28,19,self.C.ink)
   self:label(stocks,'Зайнято '..P.number(store.used)..' · Резерв '..P.number(store.reservedSpace)..' · Вільно '..P.number(store.free),16,47,half-32,33,15,self.C.muted)
   self:button(stocks,'Відкрити склад',16,87,160,31,function()self.storageTab='goods';self:showPage('storage')end)
   self:label(stocks,'Водосховище',half+28,12,half-32,28,19,self.C.blue)
   self:label(stocks,P.number(water.quantity)..' / '..P.number(water.capacity),half+28,47,half-32,33,15,self.C.muted)
   self:button(stocks,'Відкрити баки',half+28,87,160,31,function()self.storageTab='water';self:showPage('storage')end)
   self:card('Операції','Знахідки: '..P.count(state.sites)..' · Бригади: '..P.count(state.crews)..' · Рейси: '..P.count(state.flights),{{'Дослідники',function()self:showPage('researchers')end},{'Видобуток',function()self:showPage('mining')end},{'Перевізники',function()self:showPage('transport')end}})
   self:lineList(s)
  elseif self.page=='production'then
   self:card('Розвиток виробництва','Кожна машина використовує площу. Сировина і вода списуються за завершений цикл.',{A('Додати лінію','line.add',{}, {choice('family','Тип виробництва',families,'furnace'),n('tier','Тір',1)}),A('Площа','factory.expand')})
   self:lineList(s)
  elseif self.page=='storage'then
   local st=state.storage or{};local water=state.water or{}
   local tab=self.storageTab or'goods'
   local tabs=self:row(48)
   self:button(tabs,'Склад',0,0,146,38,function()self.storageTab='goods';self.pageIndex=1;self:render()end,tab=='goods')
   self:button(tabs,'Водосховище',154,0,178,38,function()self.storageTab='water';self.pageIndex=1;self:render()end,tab=='water')
   if tab=='water'then
    self:card('Водосховище',P.number(water.quantity)..' / '..P.number(water.capacity),{A('Додати бак','tank.add',{}, {n('tier','Тір бака',1)}),A('Купити воду','market.buy',{itemId='water'},{n('quantity','Кількість води',1000)})})
    for _,tank in ipairs(P.rows(water.tanks))do self:card('Бак '..tostring(tank.id),'Тір '..P.number(tank.tier)..' · Місткість '..P.number(tank.capacity),{A('Покращити','tank.upgrade',{id=tank.id})},140)end
    for _,job in ipairs(P.rows(st.incoming))do
     if job.itemId=='water'then self:card('Очікується вода',P.number(job.remaining or job.quantity)..' · '..P.status(job.status),nil,104)end
    end
    return
   end
   self:card('Товарна місткість','Зайнято '..P.number(st.used)..' · Місце під поставки '..P.number(st.reservedSpace)..' · Вільно '..P.number(st.free)..' / '..P.number(st.capacity),{A('Розширити склад','warehouse.expand'),{'Внести з рюкзака',function()self:inspectInventory()end}})
   self:productToolbar()
   self:productHeader({'Товар','Наявно','Резерв','Доступно'})
   self:products(s,st.items,function(row)
    local reserved=(st.reserved or{})[row.id]or 0
    self:productRow(P.item(s,row.id),{P.number(row.value),P.number(reserved),P.number(math.max(0,row.value-reserved))},{A('Продати','market.offer',{itemId=row.id},{n('quantity','Кількість',1),choice('mode','Режим',{{'market','Ринкова ціна'},{'fixed','Фіксована ціна'}},'market'),{key='price',label='Ціна за одиницю (лише фіксований режим)',number=true,integer=false,min=.01,default=1}})})
   end)
   self:card('Фізична видача','Виведення предметів у рюкзак поки не підтримане native-адаптером. Товар залишається на складі.',nil,106)
   for _,job in ipairs(P.rows(st.incoming))do
    if job.itemId~='water'then self:card('Очікується: '..P.item(s,job.itemId),'Залишок '..P.number(job.remaining or job.quantity)..' · '..P.status(job.status),nil,104)end
   end
  elseif self.page=='trade'then
   self:reputation(s,'trade')
   self:card('Торгові розділи','Купівля, власні пропозиції та поставки за контрактами.',{{'Каталог',function()self.tradeTab='catalog';self.pageIndex=1;self:render()end},{'Мої пропозиції',function()self.tradeTab='offers';self.pageIndex=1;self:render()end},{'Контракти',function()self.tradeTab='quests';self.pageIndex=1;self:render()end}})
   if self.tradeTab=='offers'then
    self:paginate(P.rows(state.offers),function(o)self:card(P.item(s,o.itemId),P.status(o.status)..' · Залишок '..P.number(o.remaining)..' · '..tostring(o.mode)..' · Ціна '..P.number(o.price),{A('Скасувати','market.cancel',{id=o.id})})end)
   elseif self.tradeTab=='quests'then self:quests(s)
   else
    self:productToolbar()
    self:productHeader({'Товар','Запас','Ціна за од.'})
    self:products(s,s.catalog.items,function(row)
     local market=(state.market or{})[row.id]or{};local item=s.catalog.items[row.id]
     self:productRow(P.item(s,row.id),{P.number(market.stock),P.number(market.buyPrice or item.buyPrice)..' ¤'},{A('Купити','market.buy',{itemId=row.id},{n('quantity','Кількість',1)}),A('Спецзамов.','market.special',{itemId=row.id},{n('quantity','Кількість',1)})})
    end)
   end
  elseif self.page=='researchers'then
   self:reputation(s,'researchers');local resources={{'any','Будь-який ресурс'}}
   for _,r in ipairs(P.rows(s.catalog.items))do local item=s.catalog.items[r.id];if item.kind=='ore'then resources[#resources+1]={r.id,P.item(s,r.id)}end end
   self:card('Пошукові групи','Доступно груп: '..P.number(state.searchGroups)..'. Автоповтор обмежений бюджетом.',{A('Новий пошук','search.start',{}, {choice('kind','Тип точки',{{'ore','Родовище'},{'station','Станція'}},'ore'),choice('resource','Ресурс',resources,'any'),n('minTier','Мінімальний рівень',1),choice('probe','Зонд',yesno,false),choice('auto','Автоповтор',yesno,false),n('budget','Загальний бюджет',s.config and s.config.searchPrice or 10000)}),A('Додати групу','search.group')})
   for _,job in ipairs(P.rows(state.searches))do self:card('Пошук '..tostring(job.id),P.status(job.status)..' · До завершення '..P.duration((job.finish or 0)-(s.now or 0))..' · Бюджет '..P.number(job.budget),{A('Зупинити повтор','search.cancel',{id=job.id})},144)end
   self:sites(s,'researchers')
  elseif self.page=='mining'then
   self:reputation(s,'mining');local m=state.mining or{}
   self:card('Бригади та обладнання','Найнято '..P.number(m.hired)..' / '..P.number(m.available)..' · Зайнято '..P.number(m.occupied)..' · Обладнання Mk '..P.number(state.equipment),{A('Найняти бригаду','crew.hire'),A('Краще обладнання','crew.equipment')})
   self:sites(s,'mining')
   for _,crew in ipairs(P.rows(state.crews))do self:card('Бригада '..tostring(crew.id),P.status(crew.status)..' · Точка '..tostring(crew.siteId or'—'),nil,104)end
  elseif self.page=='pmc'then
   self:reputation(s,'pmc');self:card('Оснащення ПВК','Рівень: '..P.number(state.pmcEquipment)..' / 3',{A('Покращити','pmc.equipment')});self:sites(s,'pmc')
  elseif self.page=='transport'then
   self:reputation(s,'transport');self:card('Транспортна служба','Бортів: '..P.count(state.boats)..'. Рейси вантажів і повернення людей показані окремо.',{A('Додати борт','transport.expand')})
   self:paginate(P.rows(state.flights),function(f)
    bindCard(self,'Рейс '..tostring(f.id),function(v)local row=(v.state.flights or{})[f.id]or f;return P.status(row.status)..' · '..P.item(v,row.itemId)..' × '..P.number(row.quantity)..'\nПрибуття через '..P.duration((row.finish or row.arrive or 0)-(v.now or 0))end,nil,150)
   end)
   for _,c in ipairs(P.rows(state.crews))do if c.status=='returning'or c.status=='travelling'then self:card('Перевезення людей · '..tostring(c.id),P.status(c.status)..' · Прибуття через '..P.duration((c.arrive or 0)-(s.now or 0)),nil,104)end end
   for _,b in ipairs(P.rows(state.boats))do self:card('Борт '..tostring(b.id),P.status(b.status),nil,104)end
  elseif self.page=='engineers'then
   self:card('Водна ефективність','Рівень: '..P.number(state.waterEfficiency)..' / 9',{A('Покращити','engineers.water')})
   self:reputation(s,'engineers');self:card('Технології підприємства','Два слоти швидкості та два виходу на лінію. Дві однакові невстановлені технології можна об’єднати.',{A('Об’єднати','technology.merge',{}, {choice('type','Тип',techTypes,'speed'),n('tier','Початковий тір (1–4)',1)})})
   for _,t in ipairs(P.rows(state.technologies))do self:card(tostring(t.id),'Невстановлених: '..P.number(t.value),nil,104)end
   for _,recipe in ipairs(P.rows(s.catalog.recipes))do
    local r=s.catalog.recipes[recipe.id]
    if r.license then self:card(r.name_uk or r.name_en or recipe.id,(state.licenses or{})[recipe.id]and'Ліцензію вивчено'or'Ліцензія закрита. Досліджуйте станції або виконуйте навчальні завдання.',nil,112)end
   end
   self:quests(s);self:sites(s,'engineers')
  elseif self.page=='bank'then
   self:reputation(s,'bank');self:card('Корпоративний рахунок',P.number(state.cash)..' ¤ · Банк персонажа: '..P.number(state.nativeBalance)..' ¤\n'..tostring(state.nativeBalanceError or'Переказ підтверджується фактичною зміною гаманця.'),{A('Внести кошти','bank.deposit',{}, {n('amount','Сума внесення',1000)}),A('Вивести кошти','bank.withdraw',{}, {n('amount','Сума виведення',1000)})},184)
   for _,j in ipairs(P.rows(state.nativeJournal or state.bankJournal))do self:card(tostring(j.id)..' · '..tostring(j.action),j.review and'Потрібна звірка'or(j.ok and'Підтверджено'or'Відхилено'),nil,104)end
  elseif self.page=='journal'then
   local rows=P.rows(state.events);table.sort(rows,function(a,b)return(a.time or 0)>(b.time or 0)end)
   self:paginate(rows,function(e)self:card(P.duration(e.time)..' · '..tostring(e.kind or''),e.text or e.message or'',nil,128)end)
   for _,j in ipairs(P.rows(state.journal))do self:card('Пошуковий журнал',P.item(s,j.itemId)..' · T'..P.number(j.tier)..' · '..P.duration(j.time),nil,104)end
   for _,site in ipairs(P.rows(state.sites))do
    if site.status=='lost'or site.status=='depleted'or site.status=='buried'then
     self:card(site.name or tostring(site.id),P.status(site.status)..' · Остаточне видалення доступне лише без робіт, вантажу й рейсів.',{A('Видалити запис','site.archive',{siteId=site.id})},146)
    end
   end
  end
 end
 function ui:lineList(s)
  self:paginate(P.rows(s.state.lines),function(line)
   local id=line.id
   local actions={self:action('Завдання','line.task',{lineId=id},self:recipeFields(s,line)),self:action('Машини','line.machine',{lineId=id},{n('quantity','Додати машин',1)}),self:action('Тір','line.tier',{lineId=id}),{'Технології',function()self:lineTechnologies(id)end},self:action('Зупинити','line.stop',{lineId=id})}
   local r=self:card(line.name or tostring(id),'',actions,204)
   self:label(r,'',18,52,self.bodyWidth-40,94,18,self.C.muted,function(v)
    local l=(v.state.lines or{})[id]or line;local task=l.task or{};local recipe=v.catalog.recipes[task.recipeId]or{}
    return P.status(l.status)..' · T'..P.number(l.tier)..' · Машин '..P.number(l.machines)..'\n'..(recipe.name_uk or recipe.name_en or'Без завдання')..' · Циклів лишилось '..P.number(task.remaining)..'\n'..tostring(l.reason or'')
   end)
   self:meter(r,18,145,self.bodyWidth-40,function(v)local l=(v.state.lines or{})[id]or{};local c=l.cycle or{};return(c.elapsed or 0)/math.max(.1,c.duration or 1)end)
  end)
 end
 function ui:recipeFields(s,line)
  local recipes={};for _,r in ipairs(P.rows(s.catalog.recipes))do local v=s.catalog.recipes[r.id];if v.family==line.family then recipes[#recipes+1]={r.id,(v.name_uk or v.name_en or r.id)..' · T'..tostring(v.minTier or 1)}end end
  if #recipes==0 then recipes={{'','Немає відповідного рецепта'}}end
  return{choice('recipeId','Рецепт',recipes,recipes[1][1]),n('cycles','Кількість циклів',1),choice('auto','Автоповтор',yesno,line.auto==true),choice('clean','Сировина',{{'raw','Сира руда'},{'clean','Очищена руда'},{'auto','Автовибір'}},'raw')}
 end
 function ui:lineTechnologies(id)
  self.page='lineTech';self.selectedLine=id;self:render()
 end
 function ui:lineTechnologyScreen(id)
  local s=self.data;local line=(s.state.lines or{})[id]or{}
  self:card('Технології лінії '..tostring(id),'Швидкість: слоти 1–2. Вихід: слоти 3–4. Зняття повертає технологію без повернення плати за монтаж.',{{'До виробництва',function()self:showPage('production')end},self:action('Встановити','line.technology',{lineId=id},{choice('type','Тип',techTypes,'speed'),n('tier','Тір технології (1–5)',1),n('slot','Слот усередині типу (1–2)',1)})},184)
  for index=1,4 do local slot=index;local t=(line.technologies or{})[slot]
   self:card('Слот '..slot,t and(t.type..' · T'..tostring(t.tier))or'Порожній',t and{self:action('Зняти','line.technology.remove',{lineId=id,slot=slot})}or nil,140)
  end
  self:card('Автоматизація','Застосовується до поточного завдання.',{self:action('Налаштувати','line.automation',{lineId=id},{choice('auto','Автоповтор',yesno,line.auto==true)})})
 end
 function ui:profileScreen(s)
  local info=s.profile
  if not info and self.service.profile_context then local ok,v=pcall(function()return self.service:profile_context()end);if ok then info=v end end
  if not info or not info.session then self:card('Профіль недоступний',s.profileError or s.notice or'Завантажте персонажа в одиночній грі.');return end
  local function openProfile(id)
   local result=self.service:dispatch('profile.select',{id=id,session=info.session,confirmed=true})
   if not result or not result.ok then
    self:notice(result and result.error or'Не вдалося відкрити профіль.')
    return
   end
   self.page='overview'
   self.message='Профіль підприємства відкрито.'
   self:render()
  end
  self:card('Підприємство для цього сейву','Персонаж: '..tostring(info.characterLabel or'—')..' · Світ: '..tostring(info.worldLabel or'—')..'\nОбирайте лише профіль, який створили для цього персонажа й сейву.',nil,130)
  local row=self:row(118)
  self:label(row,'Назва нового профілю: малі латинські літери, цифри, _ або -',16,10,self.bodyWidth-32,34,17,self.C.muted)
  local name=self:input(row,'',16,52,self.bodyWidth-316,42)
  self:button(row,'Створити й відкрити',self.bodyWidth-284,52,268,42,function()
   local id=self:inputText(name):match('^%s*(.-)%s*$')
   if #id>48 or not id:match('^[a-z0-9][a-z0-9_%-]*$')then
    self:notice('Введіть від 1 до 48 символів. Почніть із малої латинської літери або цифри.')
    return
   end
   for _,profile in ipairs(info.saved or{})do
    if profile.id==id then
     self:notice('Ця назва вже є. Відкрийте наявний профіль нижче або введіть іншу назву.')
     return
    end
   end
   openProfile(id)
  end,true)
  for _,profile in ipairs(info.saved or{})do
   local id=profile.id
   self:card('Профіль '..tostring(id),'Натискаючи кнопку, ви підтверджуєте належність профілю цьому персонажу й сейву.',{{'Це мій профіль — відкрити',function()openProfile(id)end}},144)
  end
 end
 function ui:quests(s)
  self:paginate(P.rows(s.state.quests),function(q)
   self:card(q.name or('Поставка: '..P.item(s,q.itemId)),P.status(q.status)..' · Доставлено '..P.number(q.delivered)..' / '..P.number(q.quantity)..' · Винагорода '..P.number(q.reward or q.price),{q.status=='offered'and self:action('Прийняти','quest.accept',{id=q.id})or self:action('Поставити частину','quest.complete',{id=q.id},{n('quantity','Кількість',1)})},154)
  end)
 end
 function ui:sites(s,scope)
  local rows={}
  for _,site in ipairs(P.rows(s.state.sites))do
   local working=site.order or site.status=='mining'or site.status=='returning'
   local show=(scope=='researchers'and not working and site.status~='transferred'and site.status~='lost')or(scope=='mining'and site.kind=='ore'and(site.known or working))or(scope=='pmc'and(site.danger or(site.job and site.job.kind=='clear')))or(scope=='engineers'and site.infinite and site.status~='transferred'and site.status~='lost')
   if show then rows[#rows+1]=site end
  end
  self:paginate(rows,function(site)
   local id=site.id;local a={}
   if scope=='pmc'then a[#a+1]=self:action('Зачистка','site.clear',{siteId=id},{{key='funding',label='Фінансування (0,5–3)',number=true,integer=false,min=.5,default=1}})
   elseif scope=='researchers'then
    a[#a+1]=self:action('Дослідити','site.research',{siteId=id})
    if site.reward then a[#a+1]=self:action('Придбати знахідку','technology.buy',{siteId=id})end
    if site.kind=='ore'then a[#a+1]=self:action('Передати NPC','site.transfer',{siteId=id})end
   elseif scope=='mining'then
    a[#a+1]=self:action('Видобувати','site.mine',{siteId=id},{n('quantity','Обсяг замовлення',site.remaining or 1),n('team','Розмір команди',1)})
    if site.order then a[#a+1]=self:action('Зупинити роботи','operation.cancel',{siteId=id})end
   else a[#a+1]=self:action('Захистити','site.protect',{siteId=id});a[#a+1]=self:action('Відновити','site.restore',{siteId=id})end
   local r=self:card(site.name or tostring(id),'',a,218)
   self:label(r,'',18,50,self.bodyWidth-40,110,17,self.C.muted,function(v)
    local t=(v.state.sites or{})[id]or site;local order=t.order or{}
    return P.item(v,t.itemId)..' · T'..P.number(t.tier)..' · '..P.status(t.status)..(t.danger and' · Небезпечно'or'')..'\nЗалишок: '..(t.infinite and'До бурі'or P.number(t.remaining))..' · Видобуто: '..P.number(order.mined)..'\nВантаж на точці: '..P.number(t.buffer)..' · Доставлено: '..P.number(t.delivered)..(t.job and(' · Роботи: '..P.duration((t.job.finish or 0)-(v.now or 0)))or'')
   end)
   self:meter(r,18,158,(self.bodyWidth-54)/2,function(v)local t=(v.state.sites or{})[id]or{};local o=t.order or{};return(o.mined or 0)/math.max(1,o.quantity or 1)end)
   self:meter(r,32+(self.bodyWidth-54)/2,158,(self.bodyWidth-54)/2,function(v)local t=(v.state.sites or{})[id]or{};local o=t.order or{};return(t.delivered or 0)/math.max(1,o.quantity or 1)end,self.C.blue)
  end)
 end
end
return M
