# Bigger Bags Bigger Heists - 10x Loot Capacity

Your getaway deserves more loot and fewer trips to the van.

BagCapacity10x raises the loose-loot capacity of a bag from 12 to 120 internal units. Keep collecting jewelry and other loose loot into the same bag for longer. This changes capacity, not item prices or the number of bags you can carry.

## Experimental release

Version 0.1.0-test. The native patch was confirmed applied in the running game. A complete gameplay validation of the tenfold capacity, fill display, throwing/re-picking, deposit accounting and mission completion has not yet been confirmed. Download as an experimental build and report results.

## What changes

Five verified code locations are patched in process memory: capacity thresholds and related remaining-space calculations. The executable on disk stays unchanged. The DLL checks the executable's PE information, original instruction bytes and capacity constant before applying the patch.

This build targets only Steam build 25106786. The optional installer checks executable SHA-256 BA3FC33EADE72E89293A13E6FCC549F4C765098AD1B66F5D73E39AEDF3A3BDF9. A game update requires a new compatibility review.

## Limits

- Intended for loose loot collected into bags, not large carryable objects or pre-made bags.
- Vanilla behavior can treat a dropped or pre-made bag as closed to further filling after pickup; this mod preserves that behavior.
- Loot prices, loot weight and the carried-bag count limit are unchanged.
- Shared bag logic may also affect bots; bot behavior is untested.
- Avoid other mods that patch bag capacity or the same executable instructions.

## Enable and troubleshoot

Enable line: BagCapacity10x : 1

Disable an older BagCapacityResearch entry if present. The Lua loader requires package.loadlib; the included Windows x64 DLL is required and must remain in BagCapacity10x/Scripts/native. No separate compiler is required to play. C source is included for inspection.

Log: ue4ss/Mods/BagCapacity10x/Scripts/native/BagCapacity10x.log. APPLIED confirms the memory patch, not full gameplay correctness. REFUSED means compatibility checks rejected the patch. If a rollback-incomplete message appears, close the game before continuing. Disabling the mod and restarting restores vanilla memory; there is no modified EXE to restore.

## Requirements

Windows x64 and Crime Boss: Rockay City, Steam build 25106786.
Install UE4SS separately from https://github.com/UE4SS-RE/RE-UE4SS/releases .
The tested loader is UE4SS v3.0.1-971-g9ec5ece7 (experimental development build). Compatibility with other UE4SS versions is not confirmed; do not assume stable v3.0.1 exposes the same APIs. UE4SS is not bundled.

Use the UE4SS layout with UE4SS.dll in CrimeBoss/Binaries/Win64/ue4ss and the proxy DLL beside the game executable. Neither mod requires the other.

## Installation

Close the game. Back up ue4ss/Mods/mods.txt, then copy this archive's named mod folder into CrimeBoss/Binaries/Win64/ue4ss/Mods. Add the enable line shown below to mods.txt, replacing an existing entry for that mod rather than duplicating it. Start the game normally.

Alternatively, run the included Install.ps1 with -GameRoot pointing to your CrimeBossRockayCity installation folder. The optional installer checks the tested game executable and backs up the existing mod/configuration. It does not install UE4SS. Manual installation does not verify the executable hash.

Close and restart the game after installing, disabling or updating. Set the mod entry to 0 to disable it, or use Disable.ps1 with -GameRoot. Do not replace your entire mods.txt with another user's file.

## Compatibility

Verified configuration: Steam build 25106786, Windows x64, UE4SS v3.0.1-971-g9ec5ece7. Other game builds/storefronts and multiplayer are untested. No online compatibility or online benefits are promised.

The cover is AI-generated promotional artwork, not an in-game screenshot.