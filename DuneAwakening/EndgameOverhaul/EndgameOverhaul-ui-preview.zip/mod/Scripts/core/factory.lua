local M={}
function M.attach(E,U)
 local C=E.config
 local function line(p)local l=E.state.lines[p.lineId or p.id];assert(l,'Виберіть виробничу лінію.');return l end
 local function recipe(l,id)
  local r=E.catalog.recipes[id];assert(r,'Рецепт не знайдений.');assert(r.family==l.family,'Рецепт не підходить цій лінії.')
  assert(l.tier>=(r.minTier or 1),'Потрібне обладнання вищого тіру.')
  assert(not r.license or E.state.licenses[id],'Спочатку вивчіть креслення рецепта.')
  local v=r.variants and(r.variants[l.tier]or r.variants[tostring(l.tier)]or r)or r
  assert(v,'Рецепт недоступний на цьому тірі.');return r,v
 end
 local function bonuses(l)
  local speed,yield=0,0
  for _,t in pairs(l.technologies or{})do
   if t.type=='speed'then speed=speed+(C.technologySpeed[t.tier]or 0)else yield=yield+(C.technologyYield[t.tier]or 0)end
  end
  return speed,yield
 end
 local function installCost(l)
  local cost=0;for _,t in pairs(l.technologies or{})do cost=cost+C.technologyInstall*2^(t.tier-1)end;return cost
 end
 local function machineCost(l,n,tier)return(C.machinePrices[l.family]or C.machinePrices.furnace)*C.machineGrowth^(n-1)*C.tierFactors[tier or l.tier]+installCost(l)end
 local function newLine(family,machines,tier)
  local id=E:id('line');local l={id=id,name=family..' '..id,family=family,machines=machines or 1,tier=tier or 1,status='idle',technologies={},produced=0}
  E.state.lines[id]=l;return l
 end
 E:register('factory.open',function(p,dry)
  assert(not E.state.created,'Підприємство вже відкрите.');local quote={total=C.factoryCost,breakdown={factory=C.factoryCost}}
  assert(E.state.cash>=quote.total,'Поповніть рахунок підприємства для відкриття заводу.')
  if dry then return quote end
  E:spend(quote.total);E.state.created=true;E.state.factory.area=C.startArea;E.state.storage.capacity=C.startStorage
  E.state.water.tanks={{id='tank-1',tier=1,capacity=C.startWater}};E.state.water.capacity=C.startWater
  newLine('furnace',1,1)
  for i=1,C.startBoats do local id=E:id('boat');E.state.boats[id]={id=id,status='idle'}end
  local id=E:id('crew');E.state.crews[id]={id=id,status='idle'}
  E:event('Відкрито підприємство. Перша піч, склад і бак готові.','factory');return quote
 end)
 E:register('factory.expand',function(p,dry)
  assert(E.state.created,'Спочатку відкрийте підприємство.')
  local price=U.money(C.areaCost*C.areaGrowth^E.state.factory.expansions)
  if dry then return{total=price,outputs={area=C.areaStep}}end
  E:spend(price);E.state.factory.expansions=E.state.factory.expansions+1;E.state.factory.area=E.state.factory.area+C.areaStep;return{total=price}
 end)
 E:register('warehouse.expand',function(p,dry)
  assert(E.state.created,'Підприємство не відкрите.');local n=E.state.storage.expansions
  assert(E:usedArea()<E.state.factory.area,'Для нового складу потрібна вільна площа заводу.')
  local price=U.money(C.warehouseCost*C.warehouseGrowth^n)
  if dry then return{total=price,outputs={capacity=C.warehouseStep}}end
  E:spend(price);E.state.storage.expansions=n+1;E.state.storage.capacity=E.state.storage.capacity+C.warehouseStep;return{total=price}
 end)
 E:register('tank.add',function(p,dry)
  assert(E.state.created and E:usedArea()<E.state.factory.area,'Потрібно розширити площу підприємства.')
  local tier=U.integer(p.tier or 1,1,3);local price=C.tankPrices[tier]
  if dry then return{total=price,outputs={capacity=C.tankCapacities[tier],area=1}}end
  E:spend(price);local tank={id=E:id('tank'),tier=tier,capacity=C.tankCapacities[tier]};table.insert(E.state.water.tanks,tank);E.state.water.capacity=E.state.water.capacity+tank.capacity;return tank
 end)
 E:register('tank.upgrade',function(p,dry)
  local tank;for _,v in ipairs(E.state.water.tanks)do if v.id==(p.id or p.tankId)then tank=v end end
  assert(tank,'Виберіть бак.');assert(tank.tier<3,'Бак уже максимального тіру.')
  local nextTier=tank.tier+1;local price=C.tankPrices[nextTier]-C.tankPrices[tank.tier]
  if dry then return{total=price,outputs={capacity=C.tankCapacities[nextTier]-tank.capacity,area=0}}end
  E:spend(price);E.state.water.capacity=E.state.water.capacity+C.tankCapacities[nextTier]-tank.capacity;tank.tier=nextTier;tank.capacity=C.tankCapacities[nextTier];return tank
 end)
 E:register('line.add',function(p,dry)
  assert(E.state.created,'Спочатку відкрийте підприємство.');local family=p.family or'furnace';assert(C.machinePrices[family],'Невідомий тип лінії.')
  assert(E:usedArea()<E.state.factory.area,'Немає вільного місця на заводі.')
  local count=U.count(E.state.lines);local opening=count<C.freeLineOpenings and 0 or C.lineOpeningCost+C.lineOpeningStep*(count-C.freeLineOpenings)
  local tier=U.integer(p.tier or 1,1,3);local price=opening+C.machinePrices[family]*C.tierFactors[tier]
  if dry then return{total=U.money(price),breakdown={opening=opening,equipment=price-opening},outputs={area=1}}end
  E:spend(price);return newLine(family,1,tier)
 end)
 E:register('line.machine',function(p,dry)
  local l=line(p);local count=U.integer(p.quantity or 1,1,C.machinesPerLine)
  assert(l.machines+count<=C.machinesPerLine,'Лінія вже повністю укомплектована.')
  assert(E:usedArea()+count<=E.state.factory.area,'Недостатньо площі заводу.')
  local price=0;for i=1,count do price=price+machineCost(l,l.machines+i)end
  if dry then return{total=U.money(price),outputs={machines=count,area=count}}end
  E:spend(price);l.machines=l.machines+count;return l
 end)
 E:register('line.tier',function(p,dry)
  local l=line(p);assert(l.tier<3,'Максимальний тір обладнання.');local price=0
  for n=1,l.machines do price=price+(C.machinePrices[l.family]or 400000)*C.machineGrowth^(n-1)*(C.tierFactors[l.tier+1]-C.tierFactors[l.tier])end
  if dry then return{total=U.money(price),outputs={tier=l.tier+1}}end
  E:spend(price);l.tier=l.tier+1;return l
 end)
 E:register('line.automation',function(p,dry)
  local l=line(p);assert(l.machines>=C.automationAt,'Автоповтор відкривається після розширення лінії.')
  if dry then return{total=0}end;l.auto=p.auto==true;if l.task then l.task.auto=l.auto end;return l
 end)
 E:register('line.task',function(p,dry)
  local l=line(p);assert(not l.cycle and not l.task,'Спочатку зупиніть поточне завдання.')
  local r,v=recipe(l,p.recipeId);local cycles=U.integer(p.cycles or p.quantity or 1,1,1000000)
  assert(not p.auto or l.machines>=C.automationAt,'Автоповтор ще недоступний.')
  local speed,yield=bonuses(l);local inputs,outputs={},{}
  for id,n in pairs(v.inputs or r.inputs or{})do inputs[id]=n*l.machines end
  for id,n in pairs(v.outputs or r.outputs or{})do outputs[id]=math.floor(n*l.machines*(1+yield))end
  if dry then return{total=0,duration=(v.seconds or r.seconds)*cycles/(1+speed),inputs=inputs,outputs=outputs,warning='Входи списуються по завершених циклах. За нестачі сировини робота призупиняється.'}end
  l.task={recipeId=p.recipeId,cycles=cycles,remaining=cycles,completed=0,auto=p.auto==true,clean=p.clean or'raw',started=E.state.clock};l.auto=l.task.auto;l.status='waiting';return l
 end)
 E:register('line.stop',function(p,dry)
  local l=line(p);assert(l.task,'Немає поточного завдання.')
  local immediate=p.mode=='immediate';local lost={}
  if immediate and l.cycle and E.state.clock-l.cycle.started>C.freeCancelSeconds then lost=U.copy(l.cycle.inputs)end
  if dry then return{total=0,inputs=lost,warning=immediate and'Втрачаються лише входи розпочатого циклу після безкоштовного вікна.'or'Завершити поточний цикл і зупинитися.'}end
  if immediate or not l.cycle then
   for id,n in pairs(lost)do E:take(id,n,l.id)end
   if next(lost) and l.cycle then E.state.water.quantity=E.state.water.quantity-(l.cycle.water or 0)end
   l.cycle=nil;l.task=nil;l.status='idle'
  else l.task.stopRequested=true;l.task.auto=false;l.auto=false end;return l
 end)
 E:register('line.technology',function(p,dry)
  local l=line(p);local kind=p.type or'yield';assert(kind=='yield'or kind=='speed','Невідомий тип технології.')
  local tier=U.integer(p.tier or 1,1,5);local slot=U.integer(p.slot or 1,1,2);local key=kind..':'..tier
  local index=(kind=='speed'and 0 or 2)+slot;assert(not l.technologies[index],'Слот уже зайнятий. Заміна не знищує встановлене оснащення автоматично.')
  assert((E.state.technologies[key]or 0)>0,'Немає невстановленої технології цього рівня.')
  local price=C.technologyInstall*2^(tier-1)*l.machines
  if dry then return{total=price,outputs={slot=index,tier=tier}}end
  E:spend(price);E.state.technologies[key]=E.state.technologies[key]-1;l.technologies[index]={type=kind,tier=tier};return l
 end)
 E:register('technology.merge',function(p,dry)
  local kind=p.type or'yield';assert(kind=='speed'or kind=='yield','Невідома технологія.');local tier=U.integer(p.tier or 1,1,4)
  local key=kind..':'..tier;assert((E.state.technologies[key]or 0)>=2,'Потрібні дві однакові невстановлені технології.')
  local price=C.technologyMerge*2^(tier-1);if dry then return{total=price,outputs={[kind..':'..(tier+1)]=1}}end
  E:spend(price);E.state.technologies[key]=E.state.technologies[key]-2;local nextKey=kind..':'..(tier+1);E.state.technologies[nextKey]=(E.state.technologies[nextKey]or 0)+1;return{key=nextKey}
 end)
 E:register('line.technology.remove',function(p,dry)
  local l=line(p);assert(not l.cycle,'Зупиніть поточний цикл перед зміною технологій.')
  local index=U.integer(p.slot,1,4);local t=l.technologies[index];assert(t,'Цей слот порожній.')
  if dry then return{total=0,outputs={[t.type..':'..t.tier]=1},warning='Технологія повернеться на склад; плата встановлення не повертається.'}end
  local key=t.type..':'..t.tier;E.state.technologies[key]=(E.state.technologies[key]or 0)+1;l.technologies[index]=nil;return l
 end)
 local function begin(l)
  local task=l.task;local r,v=recipe(l,task.recipeId);local speed,yield=bonuses(l)
  local inputs,outputs={},{};local water=(v.water or r.water or 0)*l.machines
  if l.family=='cleaner'then water=water*(1-.1*(E.state.waterEfficiency or 0))end
  for id,n in pairs(v.inputs or r.inputs or{})do
   local target=id;local clean='clean_'..id
   if l.family=='furnace'and task.clean~='raw'and E.catalog.items[clean]and(task.clean=='clean'or E:available(clean)>=n*l.machines)then target=clean end
   inputs[target]=(inputs[target]or 0)+n*l.machines
  end
  for id,n in pairs(inputs)do if E:available(id)<n then l.status='paused';l.reason='Бракує сировини: '..id;return false end end
  if E.state.water.quantity<water then l.status='paused';l.reason='Немає води.';return false end
  local space=0;local remainders=U.copy(l.outputRemainders or{})
  for id,n in pairs(v.outputs or r.outputs or{})do
   local exact=n*l.machines*(1+yield)+(remainders[id]or 0)
   local qty=math.floor(exact+1e-9);remainders[id]=math.max(0,exact-qty);outputs[id]=qty;space=space+qty*(E:item(id).volume or 1)
  end
  local free=E:space();if free<space then l.status='paused';l.reason='Склад заповнений.';return false end
  -- Water is debited at cycle completion; reserve it along with item inputs.
  local reservedWater=0;for _,other in pairs(E.state.lines)do if other.cycle then reservedWater=reservedWater+(other.cycle.water or 0)end end
  if E.state.water.quantity-reservedWater<water then l.status='paused';l.reason='Вода зарезервована іншою лінією.';return false end
  l.cycle={started=E.state.clock,elapsed=0,duration=math.max(.1,(v.seconds or r.seconds)/(1+speed)),inputs=inputs,outputs=outputs,water=water,space=space,remainders=remainders}
  l.status='running';l.reason=nil;return true
 end
 E.tickers[#E.tickers+1]=function(dt)
  if not E.state.created then return end
  for _,l in pairs(E.state.lines)do
   if l.task then
    local remaining=dt;local steps=0
    while remaining>0 and l.task and steps<100 do
     steps=steps+1;if not l.cycle and not begin(l)then break end
     local cycle=l.cycle;local advance=math.min(remaining,cycle.duration-cycle.elapsed);cycle.elapsed=cycle.elapsed+advance;remaining=remaining-advance
     if cycle.elapsed+1e-7>=cycle.duration then
      for id,n in pairs(cycle.inputs)do E:take(id,n,l.id)end
      E.state.water.quantity=E.state.water.quantity-cycle.water;l.outputRemainders=cycle.remainders;l.cycle=nil
      for id,n in pairs(cycle.outputs)do E:put(id,n);l.produced=l.produced+n;E.state.statistics.produced=E.state.statistics.produced+n end
      l.task.completed=l.task.completed+1;l.task.remaining=l.task.remaining-1
      if l.task.stopRequested then l.task=nil;l.status='idle'
      elseif l.task.remaining<=0 then
       if l.task.auto then l.task.remaining=l.task.cycles;l.task.completed=0 else E:event('Завершено завдання '..l.name,'production');l.task=nil;l.status='idle'end
      end
      E.dirty=true
     else break end
    end
   end
  end
 end
end
return M
