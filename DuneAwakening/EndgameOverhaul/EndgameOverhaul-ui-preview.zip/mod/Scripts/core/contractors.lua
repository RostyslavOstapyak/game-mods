-- Compact contractor projects: no loans, personal crew levels or extra currencies.
local M={}
function M.attach(E,U)
 local C=E.config
 E:register('engineers.water',function(p,dry)
  local level=E.state.waterEfficiency or 0;assert(level<9,'Досягнуто максимальної економії води.')
  assert(E:level('engineers')>=1+level*5,'Наступне покращення ще не відкрите репутацією.')
  local price=U.money(50000*1.5^level)
  if dry then return{total=price,outputs={waterReduction=(level+1)*10},warning='Зменшує тільки воду для очищення руди; вода у хімічних рецептах лишається реагентом.'}end
  E:spend(price);E.state.waterEfficiency=level+1;E:xp('engineers',20);return{level=level+1}
 end)
 E:register('pmc.equipment',function(p,dry)
  local level=E.state.pmcEquipment or 0;assert(level<3,'Оснащення ПВК максимальне.')
  assert(E:level('pmc')>=1+level*15,'Наступне оснащення ще не відкрите репутацією.')
  local price=U.money(300000*1.75^level)
  if dry then return{total=price,outputs={level=level+1},warning='Кожен рівень дає +10% швидкості зачистки. Шанс успіху не стає гарантованим.'}end
  E:spend(price);E.state.pmcEquipment=level+1;return{level=level+1}
 end)
 local function eligibleItems()
  local available={}
  for _,line in pairs(E.state.lines)do for id,r in pairs(E.catalog.recipes)do
   if line.family==r.family and line.tier>=(r.minTier or 1)and(not r.license or E.state.licenses[id])then
    for item in pairs(r.outputs or{})do available[item]=true end
   end
  end end
  local ids={};for id in pairs(available)do ids[#ids+1]=id end;table.sort(ids);return ids
 end
 E.tickers[#E.tickers+1]=function()
  if not E.state.created or E.state.clock-(E.state.lastContractorQuest or 0)<C.questRefresh then return end
  E.state.lastContractorQuest=E.state.clock
  local items=eligibleItems();if #items==0 then return end
  for _,faction in ipairs({'mining','researchers','pmc','transport','engineers'})do
   local exists=false;for _,q in pairs(E.state.quests)do if q.faction==faction and(q.status=='offered'or q.status=='accepted')then exists=true end end
   if not exists then
    local id=items[math.floor(E:random()*#items)+1];local item=E:item(id);local quantity=math.max(1,math.min(1000,math.floor(E:marketItem(id).demand*.05)))
    local key=E:id('quest');E.state.quests[key]={id=key,faction=faction,itemId=id,quantity=quantity,delivered=0,status='offered',urgent=false,
     expires=E.state.clock+C.questRefresh,duration=86400,price=(item.sellPrice or item.basePrice or 1)*1.05,pendingBonus=0,xpBonus=25}
   end
  end
 end
end
return M
