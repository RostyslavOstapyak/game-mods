param([Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$GameRoot)
$ErrorActionPreference = 'Stop'
if (Get-Process -Name 'CrimeBoss*' -ErrorAction SilentlyContinue) { throw 'Close Crime Boss before installing.' }
$bin = Join-Path $GameRoot 'CrimeBoss\Binaries\Win64'
$exe = Join-Path $bin 'CrimeBoss-Win64-Shipping.exe'
if ((Get-FileHash -LiteralPath $exe).Hash -ne 'BA3FC33EADE72E89293A13E6FCC549F4C765098AD1B66F5D73E39AEDF3A3BDF9') { throw 'Unsupported executable. Expected Steam build 25106786. Nothing changed.' }
$mods = Join-Path $bin 'ue4ss\Mods'
if (!(Test-Path -LiteralPath (Join-Path $bin 'ue4ss\UE4SS.dll'))) { throw 'Install UE4SS first. See README.' }
$source = Join-Path $PSScriptRoot 'BagCapacity10x'
$target = Join-Path $mods 'BagCapacity10x'
$backup = Join-Path $PSScriptRoot ('backups\' + (Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Path $backup -Force | Out-Null
$config = Join-Path $mods 'mods.txt'
if (Test-Path -LiteralPath $config) { Copy-Item -LiteralPath $config -Destination (Join-Path $backup 'mods.txt') }
if (Test-Path -LiteralPath $target) { Copy-Item -LiteralPath $target -Destination (Join-Path $backup 'BagCapacity10x') -Recurse }
New-Item -ItemType Directory -Path $target -Force | Out-Null
Copy-Item -Path (Join-Path $source '*') -Destination $target -Recurse -Force
$lines = if (Test-Path -LiteralPath $config) { @(Get-Content -LiteralPath $config) } else { @() }
$lines = @($lines | Where-Object { $_ -notmatch '^\s*(BagCapacity10x|BagCapacityResearch)\s*:' })
$lines += 'BagCapacityResearch : 0'
$lines += 'BagCapacity10x : 1'
[IO.File]::WriteAllLines($config, $lines, [Text.UTF8Encoding]::new($false))
Write-Host 'BagCapacity10x 0.1.0 TEST installed. Launch the game normally.'
Write-Host ('Backup: ' + $backup)
