-- Single, bounded, read-only snapshot. Never reads struct contents or calls actor UFunctions.
return function(root)
    local sdkRequest = io.open(root .. "request-sdk-snapshot", "r")
    if sdkRequest then
        sdkRequest:close()
        GenerateSDK()
        DumpAllObjects()
    end
    local file = assert(io.open(root .. "typed-snapshot.txt", "w"))
    local function out(s) file:write(s .. "\n"); file:flush() end
    local function valid(o) return o ~= nil and o:IsValid() end
    local function describe(o) return valid(o) and o:GetFullName() or "<null>" end
    local visited = {}
    local function inspect(object)
        if not valid(object) or not valid(object:GetWorld()) then return end
        local address = object:GetAddress()
        if visited[address] then return end
        visited[address] = true
        out("OBJECT " .. object:GetFullName())
        local class = object:GetClass()
        local fields = {}
        for _ = 1, 8 do
            if not valid(class) or class:GetFullName() == "Class /Script/Engine.Actor" then break end
            class:ForEachProperty(function(p) fields[#fields + 1] = p end)
            class = class:GetSuperStruct()
        end
        for _, p in ipairs(fields) do
            local name = p:GetFName():ToString()
            if p:IsA(PropertyTypes.BoolProperty) or p:IsA(PropertyTypes.IntProperty)
                or p:IsA(PropertyTypes.FloatProperty) then
                out(" SCALAR " .. name .. "=" .. tostring(object[name]))
            elseif p:IsA(PropertyTypes.TextProperty) or p:IsA(PropertyTypes.StrProperty) or p:IsA(PropertyTypes.NameProperty) then
                local value = object[name]
                out(" TEXT " .. name .. "=" .. value:ToString())
            elseif p:IsA(PropertyTypes.ObjectProperty) then
                out(" OBJECTREF " .. name .. "=" .. describe(object[name]))
            elseif p:IsA(PropertyTypes.StructProperty) then
                out(" STRUCT " .. name .. " type=" .. p:GetStruct():GetFullName())
            elseif p:IsA(PropertyTypes.ArrayProperty) then
                local inner = p:GetInner()
                if inner:IsA(PropertyTypes.ObjectProperty) then
                    local refs = {}
                    object[name]:ForEach(function(_, param) if #refs < 40 then refs[#refs + 1] = param:get() end end)
                    for index, value in ipairs(refs) do out(" ARRAYREF " .. name .. "[" .. index .. "]=" .. describe(value)) end
                else
                    out(" ARRAY " .. name .. " inner=" .. inner:GetFullName())
                end
            end
        end
    end
    local ok, failure = pcall(function()
        for _, actor in ipairs(FindAllOf("IGS_ScriptActorBase") or {}) do inspect(actor) end
        for _, actor in ipairs(FindAllOf("IGS_ScriptManagerBase") or {}) do inspect(actor) end
        for _, trigger in ipairs(FindAllOf("IGS_LookAtTriggerComponent") or {}) do
            if valid(trigger) and valid(trigger:GetWorld()) then inspect(trigger:GetOwner()) end
        end
    end)
    if not ok then out("STOPPED " .. tostring(failure)) end
    file:close()
end
